#!/usr/bin/env bash
set -euo pipefail

echo "=== Reproducing Machine Learning Assignment 2 (Aditya Singh, P26AI0001) ==="
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1

# 1. Run Q1, Q2, and Q3 experiments and save split + logs
python3 src/run_all.py

# 2. Regenerate all figures from saved logs and split
python3 scripts/generate_figures.py

# 3. Compile 8-page CVPR report PDF
if command -v pdflatex >/dev/null 2>&1; then
  (cd report && pdflatex -interaction=nonstopmode cvpr_report_p26ai0001.tex && pdflatex -interaction=nonstopmode cvpr_report_p26ai0001.tex)
fi
echo "=== Reproduction complete! Logs in logs/, Figures in figures/, PDF in report/ ==="
