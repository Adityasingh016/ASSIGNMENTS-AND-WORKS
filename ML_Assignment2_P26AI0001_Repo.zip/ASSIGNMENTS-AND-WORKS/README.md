# Machine Learning: Assignment 2 — Bagging, Boosting, and Bias-Variance on Face Recognition

- **Student Name:** Aditya Singh
- **Roll Number:** `P26AI0001` (Numeric RNG Seed: `260001`)
- **Course:** Machine Learning (IIT Jodhpur)
- **GitHub Repository:** `https://github.com/Adityasingh016/ASSIGNMENTS-AND-WORKS` (`Adityasingh016/ASSIGNMENTS-AND-WORKS`)
- **Report Format:** CVPR Two-Column Format (8 Pages)

## Repository Structure

```text
.
├── configs/
│   └── config.yaml                     # Hyperparameter grids, frozen settings, and seed=260001
├── data/
│   └── olivetti_faces.npz              # 40 identities x 10 images (64x64) face dataset archive
├── splits/
│   ├── saved_split.npz                 # Frozen 6 train / 2 val / 2 test per-identity split (seed 260001)
│   └── saved_split.json                # Human-readable split indices
├── src/
│   ├── dataset.py                      # Dataset loader (sklearn fetch_olivetti_faces + offline archive)
│   ├── cart_tree.py                    # Vectorised CART DecisionTreeClassifier & sklearn wrapper
│   └── run_all.py                      # End-to-end execution of Q1(a-d), Q2(a-d), and Q3(a-d)
├── scripts/
│   └── generate_figures.py             # Generates all 6 publication-quality figures in figures/
├── logs/
│   ├── final_logs.json                 # Complete experimental metrics for Q1, Q2, and Q3
│   ├── q1b_bootstrap_distinct_stats.json
│   └── q2a_toy_samme_log.json
├── figures/
│   ├── q1a_depth_profile.png
│   ├── q1c_metrics_vs_B.png
│   ├── q1d_face_cases.png
│   ├── q2b_boosting_dynamics.png
│   ├── q2cd_heavy_and_masked.png
│   └── q3b_depth_bias_variance.png
├── report/
│   ├── cvpr_report_p26ai0001.tex       # LaTeX source for the 8-page CVPR two-column report
│   └── ML_Assignment2_CVPR_Report_P26AI0001.pdf
├── environment.yml                     # Conda environment specification
├── requirements.txt                    # Pip requirements specification
└── reproduce.sh                        # Exact one-command reproduction script
```

## Exact Reproduction Commands

```bash
# 1. Create environment (optional)
conda env create -f environment.yml && conda activate ml-assignment2-p26ai0001

# 2. Run the full experimental pipeline, regenerate figures, and compile the CVPR PDF
bash reproduce.sh
```
