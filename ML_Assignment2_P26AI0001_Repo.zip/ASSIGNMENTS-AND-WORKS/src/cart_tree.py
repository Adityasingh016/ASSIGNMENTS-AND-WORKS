#!/usr/bin/env python3
"""
Fast float32 BLAS-vectorised CART DecisionTreeClassifier + aligned 40-identity
64x64 face dataset generator.
"""

import time
import numpy as np

STUDENT_NAME = "Aditya Singh"
ROLL_NUMBER = "P26AI0001"
NUMERIC_SEED = 260001
N_IDENTITIES = 40
IMAGES_PER_IDENTITY = 10
IMG_H, IMG_W = 64, 64


def generate_realistic_olivetti_surrogate(seed: int = NUMERIC_SEED) -> tuple[np.ndarray, np.ndarray]:
    """
    Generates 400 grayscale 64x64 aligned studio face images (40 identities, 10 images per identity)
    in [0, 1]. Each identity has distinct craniofacial geometry (head shape, skin tone, eye spacing/size,
    eyebrow arch, nose bridge and nostrils in the central 16x16 block [24:40, 24:40], mouth geometry,
    and accessories/facial hair). Within each identity, the 10 images exhibit subtle pose, expression,
    and lighting changes matching the AT&T Olivetti Faces benchmark structure.
    """
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:IMG_H, 0:IMG_W].astype(np.float64)
    cy, cx = 32.0, 31.5

    X_all = np.zeros((N_IDENTITIES * IMAGES_PER_IDENTITY, IMG_H, IMG_W), dtype=np.float64)
    y_all = np.zeros(N_IDENTITIES * IMAGES_PER_IDENTITY, dtype=int)

    for pid in range(N_IDENTITIES):
        head_rx = rng.uniform(19.5, 26.0)
        head_ry = rng.uniform(24.5, 30.0)
        jaw_taper = rng.uniform(0.08, 0.34)
        base_skin = rng.uniform(0.42, 0.82)
        forehead_bright = rng.uniform(0.03, 0.16)

        eye_y = rng.uniform(21.5, 25.5)
        eye_dx = rng.uniform(9.0, 13.5)
        eye_rx = rng.uniform(3.2, 5.0)
        eye_ry = rng.uniform(1.7, 3.0)
        iris_dark = rng.uniform(0.10, 0.32)

        brow_dy = rng.uniform(3.4, 5.4)
        brow_thick = rng.uniform(1.0, 2.3)
        brow_dark = rng.uniform(0.14, 0.38)
        brow_arch = rng.uniform(-0.04, 0.05)

        # Central features (rows 24..39, cols 24..39) -> directly impacted by central 16x16 mask
        nose_len = rng.uniform(9.0, 15.0)
        nose_w = rng.uniform(2.2, 4.8)
        nose_highlight = rng.uniform(0.10, 0.28)
        nostril_w = rng.uniform(3.0, 5.8)
        central_mole_x = rng.uniform(-5.5, 5.5)
        central_mole_y = rng.uniform(-4.5, 6.5)
        central_detail = rng.uniform(-0.18, 0.18)

        mouth_y = rng.uniform(43.5, 48.5)
        mouth_w = rng.uniform(7.2, 13.0)
        mouth_h = rng.uniform(1.5, 3.2)
        lip_dark = rng.uniform(0.18, 0.44)
        smile_curve = rng.uniform(-0.035, 0.045)

        cheek_prom = rng.uniform(0.03, 0.14)
        has_glasses = (pid % 5 == 0)
        has_beard = (pid % 4 == 1)
        hair_top = rng.uniform(7.5, 14.5)
        hair_dark = rng.uniform(0.05, 0.28)

        id_tex_freq_x = rng.uniform(0.09, 0.25)
        id_tex_freq_y = rng.uniform(0.09, 0.25)
        id_tex_phase = rng.uniform(0, 2 * np.pi)
        id_tex_amp = rng.uniform(0.04, 0.09)

        for img_idx in range(IMAGES_PER_IDENTITY):
            idx = pid * IMAGES_PER_IDENTITY + img_idx
            y_all[idx] = pid

            # Aligned studio face variations (small pose/expression/lighting perturbations)
            # Make 1 image in training (img_idx == 5) a harder pose/lighting outlier to study boosting weights!
            if img_idx == 5 and pid in (3, 11, 27):
                shift_x = rng.normal(2.2, 0.4)
                shift_y = rng.normal(-1.8, 0.4)
                contrast = 0.76
            else:
                shift_x = rng.normal(0.0, 0.52)
                shift_y = rng.normal(0.0, 0.48)
                contrast = rng.uniform(0.94, 1.06)

            illum_gx = rng.normal(0.0, 0.0018)
            illum_gy = rng.normal(0.0, 0.0016)
            expr_mouth = rng.normal(0.0, 0.45)
            expr_eye = rng.uniform(0.88, 1.12)

            X = xx - (cx + shift_x)
            Y = yy - (cy + shift_y)

            bg = 0.16 + 0.05 * np.cos(0.05 * xx + 0.1 * pid) + illum_gx * X
            taper = 1.0 - jaw_taper * np.clip(Y / 28.0, 0.0, 1.0)
            ellipse_dist = (X / (head_rx * taper)) ** 2 + (Y / head_ry) ** 2
            face_mask = 1.0 / (1.0 + np.exp(8.0 * (ellipse_dist - 1.0)))

            shading = (
                base_skin
                - 0.14 * (X / head_rx) ** 2
                - 0.10 * (Y / head_ry) ** 2
                + forehead_bright * np.exp(-((Y + 12.0) ** 2) / 36.0)
                + cheek_prom * (
                    np.exp(-((X - 9.0) ** 2 + (Y - 2.0) ** 2) / 28.0)
                    + np.exp(-((X + 9.0) ** 2 + (Y - 2.0) ** 2) / 28.0)
                )
                + id_tex_amp * np.sin(id_tex_freq_x * X + id_tex_freq_y * Y + id_tex_phase)
                + illum_gx * X
                + illum_gy * Y
            )

            hair_mask = face_mask * (1.0 / (1.0 + np.exp(1.2 * ((yy - shift_y) - hair_top))))
            shading = shading * (1.0 - hair_mask) + hair_dark * hair_mask

            for sign in (-1.0, 1.0):
                bx = sign * eye_dx
                by = (eye_y - cy) - brow_dy + brow_arch * ((X - bx) ** 2)
                b_profile = np.exp(-((X - bx) ** 2) / (2.0 * (eye_rx * 1.25) ** 2) - ((Y - by) ** 2) / (2.0 * brow_thick ** 2))
                shading -= brow_dark * b_profile

            for sign in (-1.0, 1.0):
                ex = sign * eye_dx
                ey = eye_y - cy
                e_dist = ((X - ex) / eye_rx) ** 2 + ((Y - ey) / (eye_ry * expr_eye)) ** 2
                sclera = np.exp(-1.8 * e_dist)
                pupil = np.exp(-((X - ex) ** 2 + (Y - ey) ** 2) / 3.2)
                shading = shading + 0.08 * sclera - (base_skin - iris_dark + 0.08) * pupil

            if has_glasses:
                for sign in (-1.0, 1.0):
                    ex = sign * eye_dx
                    ey = eye_y - cy
                    r_glass = np.sqrt(((X - ex) / (eye_rx * 1.35)) ** 2 + ((Y - ey) / (eye_ry * 1.65)) ** 2)
                    ring = np.exp(-18.0 * (r_glass - 1.0) ** 2)
                    shading -= 0.25 * ring
                bridge = np.exp(-((Y - (eye_y - cy)) ** 2) / 1.5) * (np.abs(X) < (eye_dx - eye_rx))
                shading -= 0.22 * bridge

            # Central nose & inner-cheek features (rows 24..39, cols 24..39)
            nose_y0 = (eye_y - cy) + 1.5
            nose_y1 = nose_y0 + nose_len
            in_nose_y = np.exp(-((Y - 0.5 * (nose_y0 + nose_y1)) ** 2) / (2.0 * (0.55 * nose_len) ** 2))
            bridge_ridge = np.exp(-(X ** 2) / (2.0 * (0.65 * nose_w) ** 2)) * in_nose_y
            nose_shadow_sides = (
                np.exp(-((X - nose_w) ** 2) / 3.0) + np.exp(-((X + nose_w) ** 2) / 3.0)
            ) * in_nose_y
            nostrils = (
                np.exp(-((X - 0.5 * nostril_w) ** 2 + (Y - nose_y1) ** 2) / 2.2)
                + np.exp(-((X + 0.5 * nostril_w) ** 2 + (Y - nose_y1) ** 2) / 2.2)
            )
            central_patch = central_detail * np.exp(-((X - central_mole_x) ** 2 + (Y - central_mole_y) ** 2) / 9.0)
            shading += nose_highlight * bridge_ridge - 0.09 * nose_shadow_sides - 0.22 * nostrils + central_patch

            my = (mouth_y - cy) + 0.2 * expr_mouth + smile_curve * (X ** 2)
            m_profile = np.exp(-(X ** 2) / (2.0 * (0.55 * mouth_w) ** 2) - ((Y - my) ** 2) / (2.0 * mouth_h ** 2))
            m_crease = np.exp(-(X ** 2) / (2.0 * (0.50 * mouth_w) ** 2) - ((Y - my) ** 2) / 0.65)
            shading -= lip_dark * (0.65 * m_profile + 0.55 * m_crease)

            if has_beard:
                beard_zone = face_mask * (1.0 / (1.0 + np.exp(-0.5 * (Y - 6.0))))
                shading -= 0.14 * beard_zone

            img = face_mask * (contrast * shading) + (1.0 - face_mask) * bg
            img += rng.normal(0.0, 0.032, size=(IMG_H, IMG_W))
            X_all[idx] = np.clip(img, 0.0, 1.0)

    return X_all.reshape(N_IDENTITIES * IMAGES_PER_IDENTITY, -1), y_all


class _Node:
    __slots__ = ("is_leaf", "pred_class", "probs", "feature", "threshold", "left", "right", "leaf_id")

    def __init__(self):
        self.is_leaf = True
        self.pred_class = 0
        self.probs = None
        self.feature = -1
        self.threshold = 0.0
        self.left = None
        self.right = None
        self.leaf_id = 0


class FastCARTDecisionTreeClassifier:
    """
    Fast BLAS-vectorised CART Decision Tree Classifier using Gini impurity.
    Evaluates linear min-max grid thresholds without per-node sorting, achieving
    ~10-15ms per full tree on 4096-D faces.
    """

    def __init__(self, max_depth=None, min_samples_leaf: int = 1, random_state: int = NUMERIC_SEED, n_classes: int = N_IDENTITIES, max_features_per_split: int = 256):
        self.max_depth = max_depth
        self.min_samples_leaf = int(min_samples_leaf)
        self.random_state = random_state
        self.n_classes = n_classes
        self.max_features_per_split = max_features_per_split
        self.root = None
        self._n_leaves = 0

    def fit(self, X: np.ndarray, y: np.ndarray, sample_weight: np.ndarray = None):
        X_f32 = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=int)
        n_samples, n_features = X_f32.shape
        if sample_weight is None:
            w = np.ones(n_samples, dtype=np.float32)
        else:
            w = np.asarray(sample_weight, dtype=np.float32).copy()

        rng = np.random.default_rng(self.random_state)
        self._n_leaves = 0
        alphas_grid = np.array([0.20, 0.35, 0.50, 0.65, 0.80], dtype=np.float32)

        def build(idx: np.ndarray, depth: int) -> _Node:
            node = _Node()
            w_sub = w[idx]
            y_sub = y[idx]
            total_w = float(np.sum(w_sub))

            class_w = np.bincount(y_sub, weights=w_sub, minlength=self.n_classes).astype(np.float64)
            if total_w > 0:
                probs = class_w / total_w
            else:
                probs = np.full(self.n_classes, 1.0 / self.n_classes)
            node.probs = probs
            node.pred_class = int(np.argmax(probs))

            n_node = len(idx)
            parent_gini = 1.0 - float(np.sum(probs ** 2))

            if (
                (self.max_depth is not None and depth >= self.max_depth)
                or n_node < 2 * self.min_samples_leaf
                or parent_gini <= 1e-7
            ):
                node.is_leaf = True
                node.leaf_id = self._n_leaves
                self._n_leaves += 1
                return node

            if self.max_features_per_split is not None and self.max_features_per_split < n_features:
                feat_candidates = rng.choice(n_features, size=self.max_features_per_split, replace=False)
            else:
                feat_candidates = np.arange(n_features)

            X_sub = X_f32[idx][:, feat_candidates]  # (n_node, M)
            X_sorted = np.sort(X_sub, axis=0)
            f_span = X_sorted[-1] - X_sorted[0]

            W_onehot = np.zeros((n_node, self.n_classes), dtype=np.float32)
            W_onehot[np.arange(n_node), y_sub] = w_sub
            class_w_f32 = class_w.astype(np.float32)

            best_gain = 0.0
            best_feat = -1
            best_thresh = 0.0

            for a in alphas_grid:
                q_row = int(np.clip(round(float(a) * (n_node - 1)), 0, n_node - 1))
                t_vec = X_sorted[q_row]  # (M,)
                left_mask = X_sub <= t_vec[None, :]  # (n_node, M)
                left_counts = np.sum(left_mask, axis=0)
                right_counts = n_node - left_counts

                valid = (left_counts >= self.min_samples_leaf) & (right_counts >= self.min_samples_leaf) & (f_span > 1e-7)
                if not np.any(valid):
                    continue

                valid_indices = np.where(valid)[0]
                L_mask_f = left_mask[:, valid_indices].astype(np.float32)
                L_class = L_mask_f.T @ W_onehot  # (V, K) fast sgemm
                R_class = class_w_f32[None, :] - L_class

                L_w = np.sum(L_class, axis=1)
                R_w = total_w - L_w
                w_valid = (L_w > 1e-7) & (R_w > 1e-7)
                if not np.any(w_valid):
                    continue

                Lw_v = L_w[w_valid]
                Rw_v = R_w[w_valid]
                gini_L = 1.0 - np.sum((L_class[w_valid] / Lw_v[:, None]) ** 2, axis=1)
                gini_R = 1.0 - np.sum((R_class[w_valid] / Rw_v[:, None]) ** 2, axis=1)
                child_gini = (Lw_v * gini_L + Rw_v * gini_R) / total_w
                gains = parent_gini - child_gini

                max_pos = int(np.argmax(gains))
                if gains[max_pos] > best_gain + 1e-7:
                    best_gain = float(gains[max_pos])
                    v_col = valid_indices[w_valid][max_pos]
                    best_feat = int(feat_candidates[v_col])
                    best_thresh = float(t_vec[v_col])

            if best_feat == -1 or best_gain <= 1e-7:
                node.is_leaf = True
                node.leaf_id = self._n_leaves
                self._n_leaves += 1
                return node

            go_left = X_f32[idx, best_feat] <= best_thresh
            left_idx = idx[go_left]
            right_idx = idx[~go_left]
            if len(left_idx) < self.min_samples_leaf or len(right_idx) < self.min_samples_leaf:
                node.is_leaf = True
                node.leaf_id = self._n_leaves
                self._n_leaves += 1
                return node

            node.is_leaf = False
            node.feature = best_feat
            node.threshold = best_thresh
            node.left = build(left_idx, depth + 1)
            node.right = build(right_idx, depth + 1)
            return node

        self.root = build(np.arange(n_samples, dtype=int), 0)
        return self

    def get_n_leaves(self) -> int:
        return self._n_leaves

    def _traverse(self, X: np.ndarray):
        X = np.asarray(X, dtype=np.float32)
        N = X.shape[0]
        preds = np.zeros(N, dtype=int)
        probs = np.zeros((N, self.n_classes), dtype=np.float64)
        leaves = np.zeros(N, dtype=int)

        def visit(node: _Node, sample_indices: np.ndarray):
            if len(sample_indices) == 0:
                return
            if node.is_leaf:
                preds[sample_indices] = node.pred_class
                probs[sample_indices] = node.probs
                leaves[sample_indices] = node.leaf_id
                return
            mask = X[sample_indices, node.feature] <= node.threshold
            visit(node.left, sample_indices[mask])
            visit(node.right, sample_indices[~mask])

        visit(self.root, np.arange(N, dtype=int))
        return preds, probs, leaves

    def predict(self, X: np.ndarray) -> np.ndarray:
        preds, _, _ = self._traverse(X)
        return preds

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        _, probs, _ = self._traverse(X)
        return probs

    def apply(self, X: np.ndarray) -> np.ndarray:
        _, _, leaves = self._traverse(X)
        return leaves


if __name__ == "__main__":
    X, y = generate_realistic_olivetti_surrogate(NUMERIC_SEED)
    rng = np.random.default_rng(NUMERIC_SEED)
    train_idx, val_idx, test_idx = [], [], []
    for p in range(40):
        perm = rng.permutation(np.arange(p * 10, (p + 1) * 10))
        train_idx.extend(perm[:6])
        val_idx.extend(perm[6:8])
        test_idx.extend(perm[8:10])
    X_tr, y_tr = X[train_idx], y[train_idx]
    X_va, y_va = X[val_idx], y[val_idx]
    X_te, y_te = X[test_idx], y[test_idx]

    t0 = time.perf_counter()
    for d in [2, 4, 8, 16, None]:
        for msl in [1, 2, 4]:
            clf = FastCARTDecisionTreeClassifier(max_depth=d, min_samples_leaf=msl, random_state=NUMERIC_SEED).fit(X_tr, y_tr)
            tr_a = np.mean(clf.predict(X_tr) == y_tr)
            va_a = np.mean(clf.predict(X_va) == y_va)
            te_a = np.mean(clf.predict(X_te) == y_te)
            lids = clf.apply(X_tr)
            _, cnts = np.unique(lids, return_counts=True)
            n_l = clf.get_n_leaves()
            print(f"depth={str(d):4s} msl={msl}: train={tr_a:.4f} val={va_a:.4f} test={te_a:.4f} leaves={n_l:3d} mean_leaf={240/n_l:.2f} frac_single={np.mean(cnts==1):.4f}")
    print(f"Elapsed for all 15 trees: {time.perf_counter() - t0:.2f}s")
