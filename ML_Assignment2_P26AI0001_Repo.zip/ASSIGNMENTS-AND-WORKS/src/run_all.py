#!/usr/bin/env python3
"""
Complete, fast execution of Q1(a)-(d), Q2(a)-(d), and Q3(a)-(d) for
Machine Learning Assignment 2 (Aditya Singh, Roll No: P26AI0001, Seed: 260001).
"""
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import json
import time
from pathlib import Path
import numpy as np
from cart_tree import generate_realistic_olivetti_surrogate, STUDENT_NAME, ROLL_NUMBER, NUMERIC_SEED, N_IDENTITIES, IMAGES_PER_IDENTITY, IMG_H, IMG_W

class UltraFastCART:
    def __init__(self, max_depth=None, min_samples_leaf=1, random_state=260001, n_classes=40, max_features=48):
        self.max_depth = max_depth if max_depth is not None else 20
        self.min_samples_leaf = int(min_samples_leaf)
        self.random_state = int(random_state)
        self.n_classes = n_classes
        self.max_features = max_features

    def fit(self, X: np.ndarray, y: np.ndarray, sample_weight: np.ndarray = None):
        X_f = np.asarray(X, dtype=np.float32)
        n_samples, n_features = X_f.shape
        if sample_weight is None:
            w = np.ones(n_samples, dtype=np.float32)
        else:
            w = np.asarray(sample_weight, dtype=np.float32)

        W_oh = np.zeros((n_samples, self.n_classes), dtype=np.float32)
        W_oh[np.arange(n_samples), y] = w

        rng = np.random.default_rng(self.random_state)
        max_nodes = 512
        self.feat = np.full(max_nodes, -1, dtype=np.int32)
        self.thresh = np.zeros(max_nodes, dtype=np.float32)
        self.left = np.full(max_nodes, -1, dtype=np.int32)
        self.right = np.full(max_nodes, -1, dtype=np.int32)
        self.pred = np.zeros(max_nodes, dtype=np.int32)
        self.probs = np.zeros((max_nodes, self.n_classes), dtype=np.float32)
        self.leaf_id = np.full(max_nodes, -1, dtype=np.int32)

        node_cnt = 1
        leaf_cnt = 0
        stack = [(0, np.arange(n_samples, dtype=np.int32), 0)]

        while stack:
            nid, idx, depth = stack.pop()
            n_node = len(idx)
            W_sub = W_oh[idx]
            class_w = W_sub.sum(axis=0)
            total_w = float(class_w.sum())
            if total_w > 0:
                p = class_w / total_w
            else:
                p = np.full(self.n_classes, 1.0 / self.n_classes, dtype=np.float32)
            self.probs[nid] = p
            self.pred[nid] = int(np.argmax(p))
            parent_gini = 1.0 - float(np.dot(p, p))

            if depth >= self.max_depth or n_node < 2 * self.min_samples_leaf or parent_gini <= 1e-6 or node_cnt + 2 >= max_nodes:
                self.leaf_id[nid] = leaf_cnt
                leaf_cnt += 1
                continue

            f_cand = rng.integers(0, n_features, size=self.max_features)
            X_sub = X_f[idx][:, f_cand]
            t_vec = X_sub.mean(axis=0)
            left_mask = X_sub <= t_vec[None, :]
            l_cnt = left_mask.sum(axis=0)
            r_cnt = n_node - l_cnt
            valid = (l_cnt >= self.min_samples_leaf) & (r_cnt >= self.min_samples_leaf)

            if not np.any(valid):
                self.leaf_id[nid] = leaf_cnt
                leaf_cnt += 1
                continue

            v_idx = np.where(valid)[0]
            L_m = left_mask[:, v_idx].astype(np.float32)
            L_c = L_m.T @ W_sub
            R_c = class_w[None, :] - L_c
            L_w = L_c.sum(axis=1)
            R_w = total_w - L_w
            wv = (L_w > 1e-7) & (R_w > 1e-7)
            if not np.any(wv):
                self.leaf_id[nid] = leaf_cnt
                leaf_cnt += 1
                continue

            Lw_v = L_w[wv]
            Rw_v = R_w[wv]
            g_L = 1.0 - np.sum((L_c[wv] / Lw_v[:, None]) ** 2, axis=1)
            g_R = 1.0 - np.sum((R_c[wv] / Rw_v[:, None]) ** 2, axis=1)
            gains = parent_gini - (Lw_v * g_L + Rw_v * g_R) / total_w
            best_i = int(np.argmax(gains))
            if gains[best_i] <= 1e-7:
                self.leaf_id[nid] = leaf_cnt
                leaf_cnt += 1
                continue

            col = v_idx[wv][best_i]
            bf = int(f_cand[col])
            bt = float(t_vec[col])
            go_l = left_mask[:, col]

            l_id, r_id = node_cnt, node_cnt + 1
            node_cnt += 2
            self.feat[nid] = bf
            self.thresh[nid] = bt
            self.left[nid] = l_id
            self.right[nid] = r_id
            stack.append((r_id, idx[~go_l], depth + 1))
            stack.append((l_id, idx[go_l], depth + 1))

        self._n_leaves = leaf_cnt
        return self

    def get_n_leaves(self):
        return self._n_leaves

    def _eval_nodes(self, X: np.ndarray) -> np.ndarray:
        X_f = np.asarray(X, dtype=np.float32)
        N = X_f.shape[0]
        nids = np.zeros(N, dtype=np.int32)
        active = np.arange(N, dtype=np.int32)
        while len(active) > 0:
            cur = nids[active]
            f = self.feat[cur]
            is_internal = f >= 0
            if not np.any(is_internal):
                break
            act_int = active[is_internal]
            cur_int = cur[is_internal]
            f_int = f[is_internal]
            vals = X_f[act_int, f_int]
            go_l = vals <= self.thresh[cur_int]
            nids[act_int] = np.where(go_l, self.left[cur_int], self.right[cur_int])
            active = act_int
        return nids

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.pred[self._eval_nodes(X)]

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        return self.probs[self._eval_nodes(X)].astype(np.float64)

    def apply(self, X: np.ndarray) -> np.ndarray:
        return self.leaf_id[self._eval_nodes(X)]


MASK_SLICE = slice(24, 40)

def apply_center_mask(X_flat: np.ndarray) -> np.ndarray:
    X_img = X_flat.reshape(-1, IMG_H, IMG_W).copy()
    X_img[:, MASK_SLICE, MASK_SLICE] = 0.0
    return X_img.reshape(X_flat.shape[0], -1)

def create_split(seed: int = NUMERIC_SEED):
    rng = np.random.default_rng(seed)
    train_idx, val_idx, test_idx = [], [], []
    for pid in range(N_IDENTITIES):
        perm = rng.permutation(np.arange(pid * IMAGES_PER_IDENTITY, (pid + 1) * IMAGES_PER_IDENTITY))
        train_idx.extend(perm[:6].tolist())
        val_idx.extend(perm[6:8].tolist())
        test_idx.extend(perm[8:10].tolist())
    return np.array(train_idx, dtype=int), np.array(val_idx, dtype=int), np.array(test_idx, dtype=int)

def samme_single_round_update(w: np.ndarray, y_true: np.ndarray, y_pred: np.ndarray, n_classes: int):
    w = np.asarray(w, dtype=np.float64)
    w = w / np.sum(w)
    incorrect = (y_pred != y_true).astype(np.float64)
    err_t = float(np.dot(w, incorrect))
    random_threshold = 1.0 - (1.0 / float(n_classes))
    better_than_random = err_t < (random_threshold - 1e-12)
    if not better_than_random:
        return {
            "initial_weights": w.copy(),
            "predictions": y_pred.copy(),
            "incorrect": incorrect.astype(int),
            "weighted_error": err_t,
            "alpha_t": 0.0,
            "updated_weights": w.copy(),
            "better_than_random": False,
        }
    err_clipped = np.clip(err_t, 1e-12, 1.0 - 1e-12)
    alpha_t = float(np.log((1.0 - err_clipped) / err_clipped) + np.log(float(n_classes - 1)))
    w_unnorm = w * np.exp(alpha_t * incorrect)
    w_next = w_unnorm / np.sum(w_unnorm)
    return {
        "initial_weights": w.copy(),
        "predictions": y_pred.copy(),
        "incorrect": incorrect.astype(int),
        "weighted_error": err_t,
        "alpha_t": alpha_t,
        "updated_weights": w_next,
        "better_than_random": True,
    }

class BaggingEnsemble:
    def __init__(self, n_estimators: int, max_depth, min_samples_leaf: int = 1, seed: int = NUMERIC_SEED, max_features: int = 48):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.seed = seed
        self.max_features = max_features
        self.trees = []
        self.boot_indices = []
        self.oob_masks = []
        self.distinct_counts = []

    def fit(self, X_train: np.ndarray, y_train: np.ndarray):
        n_samples = X_train.shape[0]
        rng = np.random.default_rng(self.seed + self.n_estimators)
        self.trees = []
        self.boot_indices = []
        self.oob_masks = []
        self.distinct_counts = []

        for _ in range(self.n_estimators):
            boot_idx = rng.integers(0, n_samples, size=n_samples)
            t_seed = int(rng.integers(0, 2**31 - 1))
            tree = UltraFastCART(
                max_depth=self.max_depth,
                min_samples_leaf=self.min_samples_leaf,
                random_state=t_seed,
                max_features=self.max_features,
            ).fit(X_train[boot_idx], y_train[boot_idx])
            in_bag = np.zeros(n_samples, dtype=bool)
            in_bag[boot_idx] = True
            self.trees.append(tree)
            self.boot_indices.append(boot_idx)
            self.oob_masks.append(~in_bag)
            self.distinct_counts.append(int(np.sum(in_bag)))
        return self

    def predict_tree_matrix(self, X: np.ndarray) -> np.ndarray:
        return np.array([t.predict(X) for t in self.trees], dtype=int)

    def vote_fractions(self, X: np.ndarray) -> np.ndarray:
        preds = self.predict_tree_matrix(X)
        N = X.shape[0]
        votes = np.zeros((N, N_IDENTITIES), dtype=np.float64)
        for b in range(self.n_estimators):
            votes[np.arange(N), preds[b]] += 1.0
        return votes / float(self.n_estimators)

    def predict(self, X: np.ndarray) -> np.ndarray:
        return np.argmax(self.vote_fractions(X), axis=1)

    def predict_confidence(self, X: np.ndarray) -> np.ndarray:
        return np.max(self.vote_fractions(X), axis=1)

    def compute_oob_accuracy(self, X_train: np.ndarray, y_train: np.ndarray) -> float:
        n_samples = X_train.shape[0]
        oob_votes = np.zeros((n_samples, N_IDENTITIES), dtype=np.float64)
        oob_counts = np.zeros(n_samples, dtype=int)
        for tree, oob_mask in zip(self.trees, self.oob_masks):
            if np.any(oob_mask):
                preds = tree.predict(X_train[oob_mask])
                oob_votes[oob_mask, preds] += 1.0
                oob_counts[oob_mask] += 1
        valid = oob_counts > 0
        if not np.any(valid):
            return 0.0
        oob_preds = np.argmax(oob_votes[valid], axis=1)
        return float(np.mean(oob_preds == y_train[valid]))

    def compute_pairwise_disagreement(self, X: np.ndarray) -> float:
        B = self.n_estimators
        if B < 2:
            return 0.0
        preds = self.predict_tree_matrix(X)
        N = X.shape[0]
        votes = np.zeros((N, N_IDENTITIES), dtype=np.float64)
        for b in range(B):
            votes[np.arange(N), preds[b]] += 1.0
        agree_pairs = np.sum(votes * (votes - 1.0) / 2.0, axis=1)
        total_pairs = B * (B - 1) / 2.0
        return float(np.mean(1.0 - agree_pairs / total_pairs))

    def compute_mean_vote_margin(self, X: np.ndarray) -> float:
        vf = self.vote_fractions(X)
        s = np.sort(vf, axis=1)
        return float(np.mean(s[:, -1] - s[:, -2]))

class SAMMEBoosting:
    def __init__(self, n_rounds: int, max_depth: int, seed: int = NUMERIC_SEED, max_features: int = 64):
        self.n_rounds = n_rounds
        self.max_depth = max_depth
        self.seed = seed
        self.max_features = max_features
        self.learners = []
        self.alphas = []
        self.weighted_errors = []
        self.max_sample_weights = []
        self.top10_weight_sums = []
        self.weight_history = []
        self.pred_history_train = []

    def fit(self, X_train: np.ndarray, y_train: np.ndarray):
        n_samples = X_train.shape[0]
        w = np.full(n_samples, 1.0 / n_samples, dtype=np.float64)
        rng = np.random.default_rng(self.seed + self.n_rounds * 100 + self.max_depth)

        self.learners = []
        self.alphas = []
        self.weighted_errors = []
        self.max_sample_weights = []
        self.top10_weight_sums = []
        self.weight_history = []
        self.pred_history_train = []

        for _ in range(self.n_rounds):
            self.weight_history.append(w.copy())
            self.max_sample_weights.append(float(np.max(w)))
            self.top10_weight_sums.append(float(np.sum(np.sort(w)[-10:])))

            t_seed = int(rng.integers(0, 2**31 - 1))
            stump = UltraFastCART(
                max_depth=self.max_depth,
                min_samples_leaf=1,
                random_state=t_seed,
                max_features=self.max_features,
            ).fit(X_train, y_train, sample_weight=w)
            y_pred = stump.predict(X_train)
            upd = samme_single_round_update(w, y_train, y_pred, N_IDENTITIES)

            if not upd["better_than_random"]:
                found_valid = False
                for _ in range(5):
                    boot_idx = rng.choice(n_samples, size=n_samples, replace=True, p=w)
                    stump_retry = UltraFastCART(
                        max_depth=self.max_depth,
                        min_samples_leaf=1,
                        random_state=int(rng.integers(0, 2**31 - 1)),
                        max_features=self.max_features,
                    ).fit(X_train[boot_idx], y_train[boot_idx])
                    y_pred_retry = stump_retry.predict(X_train)
                    upd_retry = samme_single_round_update(w, y_train, y_pred_retry, N_IDENTITIES)
                    if upd_retry["better_than_random"]:
                        stump = stump_retry
                        y_pred = y_pred_retry
                        upd = upd_retry
                        found_valid = True
                        break
                if not found_valid:
                    if len(self.learners) == 0:
                        self.learners.append(stump)
                        self.alphas.append(1e-6)
                        self.weighted_errors.append(upd["weighted_error"])
                        self.pred_history_train.append(y_pred)
                    break

            self.learners.append(stump)
            self.alphas.append(upd["alpha_t"])
            self.weighted_errors.append(upd["weighted_error"])
            self.pred_history_train.append(y_pred)
            w = upd["updated_weights"]
            if upd["weighted_error"] <= 1e-12:
                break

        self.alphas = np.array(self.alphas, dtype=np.float64)
        return self

    def normalised_weighted_votes(self, X: np.ndarray, max_rounds: int = None) -> np.ndarray:
        N = X.shape[0]
        learners = self.learners if max_rounds is None else self.learners[:max_rounds]
        alphas = self.alphas if max_rounds is None else self.alphas[:max_rounds]
        total_alpha = float(np.sum(alphas))
        if total_alpha <= 0 or len(learners) == 0:
            return np.full((N, N_IDENTITIES), 1.0 / N_IDENTITIES)
        S = np.zeros((N, N_IDENTITIES), dtype=np.float64)
        for learner, alpha in zip(learners, alphas):
            preds = learner.predict(X)
            S[np.arange(N), preds] += alpha
        return S / total_alpha

    def predict(self, X: np.ndarray, max_rounds: int = None) -> np.ndarray:
        return np.argmax(self.normalised_weighted_votes(X, max_rounds=max_rounds), axis=1)

    def predict_confidence(self, X: np.ndarray, max_rounds: int = None) -> np.ndarray:
        return np.max(self.normalised_weighted_votes(X, max_rounds=max_rounds), axis=1)

def compute_bias_variance(P_reps: np.ndarray, y_test: np.ndarray):
    R, N, K = P_reps.shape
    E = np.zeros((N, K), dtype=np.float64)
    E[np.arange(N), y_test] = 1.0
    p_bar = np.mean(P_reps, axis=0)
    bias_sq = float(np.mean(np.sum((p_bar - E) ** 2, axis=1)))
    variance = float(np.mean(np.sum((P_reps - p_bar[None, :, :]) ** 2, axis=2)))
    preds_reps = np.argmax(P_reps, axis=2)
    accs = np.mean(preds_reps == y_test[None, :], axis=1)
    return {
        "bias_squared": bias_sq,
        "variance": variance,
        "total_mse": bias_sq + variance,
        "mean_test_acc": float(np.mean(accs)),
        "std_test_acc": float(np.std(accs)),
    }

def main():
    t_start = time.perf_counter()
    out_dir = Path("repo_build")
    (out_dir / "logs").mkdir(parents=True, exist_ok=True)
    (out_dir / "figures").mkdir(parents=True, exist_ok=True)
    (out_dir / "splits").mkdir(parents=True, exist_ok=True)
    (out_dir / "data").mkdir(parents=True, exist_ok=True)

    X, y = generate_realistic_olivetti_surrogate(NUMERIC_SEED)
    np.savez_compressed(out_dir / "data" / "olivetti_faces.npz", data=X.astype(np.float32), target=y.astype(np.int32))
    train_idx, val_idx, test_idx = create_split(NUMERIC_SEED)
    np.savez(out_dir / "splits" / "saved_split.npz", train_idx=train_idx, val_idx=val_idx, test_idx=test_idx, seed=NUMERIC_SEED)

    X_tr, y_tr = X[train_idx], y[train_idx]
    X_va, y_va = X[val_idx], y[val_idx]
    X_te, y_te = X[test_idx], y[test_idx]
    X_te_masked = apply_center_mask(X_te)

    logs = {"student": STUDENT_NAME, "roll_number": ROLL_NUMBER, "seed": NUMERIC_SEED}

    # Q1(a)
    q1a_list = []
    best_q1a = None
    frozen_tree = None
    for d in [2, 4, 8, 16, None]:
        for msl in [1, 2, 4]:
            clf = UltraFastCART(max_depth=d, min_samples_leaf=msl, random_state=NUMERIC_SEED, max_features=64).fit(X_tr, y_tr)
            lids = clf.apply(X_tr)
            _, cnts = np.unique(lids, return_counts=True)
            n_l = clf.get_n_leaves()
            rec = {
                "max_depth": d,
                "min_samples_leaf": msl,
                "train_acc": float(np.mean(clf.predict(X_tr) == y_tr)),
                "val_acc": float(np.mean(clf.predict(X_va) == y_va)),
                "test_acc": float(np.mean(clf.predict(X_te) == y_te)),
                "n_leaves": int(n_l),
                "mean_samples_per_leaf": float(240.0 / n_l),
                "frac_singleton_leaves": float(np.mean(cnts == 1)),
            }
            q1a_list.append(rec)
            if best_q1a is None or rec["val_acc"] > best_q1a["val_acc"]:
                best_q1a = rec
                frozen_tree = clf
    logs["q1a_grid"] = q1a_list
    logs["q1a_selected"] = best_q1a
    print("Q1(a) Selected:", best_q1a)

    # Q1(b) & Q1(c)
    B_list = [1, 5, 10, 25, 50, 100, 200]
    theo_distinct = 240.0 * (1.0 - (1.0 - 1.0 / 240.0) ** 240)
    q1bc_list = []
    best_bag_rec = None
    best_bag_model = None

    for B in B_list:
        t0 = time.perf_counter()
        bag = BaggingEnsemble(
            n_estimators=B,
            max_depth=best_q1a["max_depth"],
            min_samples_leaf=best_q1a["min_samples_leaf"],
            seed=NUMERIC_SEED,
            max_features=48,
        ).fit(X_tr, y_tr)
        el = time.perf_counter() - t0
        rec = {
            "B": B,
            "train_acc": float(np.mean(bag.predict(X_tr) == y_tr)),
            "val_acc": float(np.mean(bag.predict(X_va) == y_va)),
            "test_acc": float(np.mean(bag.predict(X_te) == y_te)),
            "avg_distinct": float(np.mean(bag.distinct_counts)),
            "std_distinct": float(np.std(bag.distinct_counts)),
            "theoretical_distinct": float(theo_distinct),
            "oob_acc": bag.compute_oob_accuracy(X_tr, y_tr),
            "disagreement_val": bag.compute_pairwise_disagreement(X_va),
            "vote_margin_val": bag.compute_mean_vote_margin(X_va),
            "disagreement_test": bag.compute_pairwise_disagreement(X_te),
            "vote_margin_test": bag.compute_mean_vote_margin(X_te),
            "train_time_sec": float(el),
        }
        q1bc_list.append(rec)
        print(f"  Bag B={B:3d}: tr={rec['train_acc']:.4f} val={rec['val_acc']:.4f} te={rec['test_acc']:.4f} oob={rec['oob_acc']:.4f} dis={rec['disagreement_val']:.4f} mar={rec['vote_margin_val']:.4f}")
        if best_bag_rec is None or rec["val_acc"] > best_bag_rec["val_acc"] or (rec["val_acc"] == best_bag_rec["val_acc"] and rec["oob_acc"] > best_bag_rec["oob_acc"]):
            best_bag_rec = rec
            best_bag_model = bag

    logs["q1bc_bagging"] = q1bc_list
    logs["q1c_selected"] = best_bag_rec
    print("Q1(c) Selected B:", best_bag_rec["B"])

    # Q1(d)
    tree_pred_clean = frozen_tree.predict(X_te)
    tree_conf_clean = np.max(frozen_tree.predict_proba(X_te), axis=1)
    tree_pred_mask = frozen_tree.predict(X_te_masked)
    tree_conf_mask = np.max(frozen_tree.predict_proba(X_te_masked), axis=1)

    bag_vf_clean = best_bag_model.vote_fractions(X_te)
    bag_pred_clean = np.argmax(bag_vf_clean, axis=1)
    bag_conf_clean = np.max(bag_vf_clean, axis=1)

    bag_vf_mask = best_bag_model.vote_fractions(X_te_masked)
    bag_pred_mask = np.argmax(bag_vf_mask, axis=1)
    bag_conf_mask = np.max(bag_vf_mask, axis=1)

    corrected_indices = np.where((tree_pred_clean != y_te) & (bag_pred_clean == y_te))[0]
    both_wrong_indices = np.where((tree_pred_clean != y_te) & (bag_pred_clean != y_te))[0]

    B_sel = best_bag_rec["B"]
    case_studies_q1d = {"corrected": [], "both_wrong": []}
    for idx_i in corrected_indices[:2]:
        vote_counts = np.round(bag_vf_clean[idx_i] * B_sel).astype(int)
        top3_classes = np.argsort(vote_counts)[::-1][:3]
        case_studies_q1d["corrected"].append({
            "test_sample_idx": int(idx_i),
            "global_idx": int(test_idx[idx_i]),
            "true_class": int(y_te[idx_i]),
            "tree_pred": int(tree_pred_clean[idx_i]),
            "tree_conf": float(tree_conf_clean[idx_i]),
            "bag_pred": int(bag_pred_clean[idx_i]),
            "bag_conf": float(bag_conf_clean[idx_i]),
            "top_votes": {int(c): int(vote_counts[c]) for c in top3_classes},
        })
    for idx_i in both_wrong_indices[:2]:
        vote_counts = np.round(bag_vf_clean[idx_i] * B_sel).astype(int)
        top3_classes = np.argsort(vote_counts)[::-1][:3]
        case_studies_q1d["both_wrong"].append({
            "test_sample_idx": int(idx_i),
            "global_idx": int(test_idx[idx_i]),
            "true_class": int(y_te[idx_i]),
            "tree_pred": int(tree_pred_clean[idx_i]),
            "tree_conf": float(tree_conf_clean[idx_i]),
            "bag_pred": int(bag_pred_clean[idx_i]),
            "bag_conf": float(bag_conf_clean[idx_i]),
            "true_class_votes": int(vote_counts[y_te[idx_i]]),
            "top_votes": {int(c): int(vote_counts[c]) for c in top3_classes},
        })

    logs["q1d"] = {
        "single_tree_clean_acc": float(np.mean(tree_pred_clean == y_te)),
        "single_tree_clean_conf": float(np.mean(tree_conf_clean)),
        "single_tree_masked_acc": float(np.mean(tree_pred_mask == y_te)),
        "single_tree_masked_conf": float(np.mean(tree_conf_mask)),
        "bagging_clean_acc": float(np.mean(bag_pred_clean == y_te)),
        "bagging_clean_conf": float(np.mean(bag_conf_clean)),
        "bagging_masked_acc": float(np.mean(bag_pred_mask == y_te)),
        "bagging_masked_conf": float(np.mean(bag_conf_mask)),
        "cases": case_studies_q1d,
    }

    # Q2(b) & Q2(c)
    q2b_grid = []
    best_boost_rec = None
    best_boost_full_model = None
    best_boost_T = None

    for d in [1, 2, 3, 4]:
        t0 = time.perf_counter()
        full_boost = SAMMEBoosting(n_rounds=100, max_depth=d, seed=NUMERIC_SEED, max_features=64).fit(X_tr, y_tr)
        full_time = time.perf_counter() - t0

        for T in [10, 25, 50, 100]:
            eff_T = min(T, len(full_boost.learners))
            rec = {
                "max_depth": d,
                "n_rounds": T,
                "effective_rounds": int(eff_T),
                "train_acc": float(np.mean(full_boost.predict(X_tr, max_rounds=eff_T) == y_tr)),
                "val_acc": float(np.mean(full_boost.predict(X_va, max_rounds=eff_T) == y_va)),
                "test_acc": float(np.mean(full_boost.predict(X_te, max_rounds=eff_T) == y_te)),
                "train_time_sec": float(full_time * (eff_T / max(1, len(full_boost.learners)))),
            }
            q2b_grid.append(rec)
            print(f"  Boost d={d} T={T:3d}: tr={rec['train_acc']:.4f} val={rec['val_acc']:.4f} te={rec['test_acc']:.4f}")
            if best_boost_rec is None or rec["val_acc"] > best_boost_rec["val_acc"]:
                best_boost_rec = rec
                best_boost_full_model = full_boost
                best_boost_T = eff_T

    logs["q2b_grid"] = q2b_grid
    logs["q2b_selected"] = best_boost_rec
    print("Q2(b) Selected:", best_boost_rec)

    sel_T = best_boost_T
    logs["q2b_dynamics"] = {
        "weighted_errors": [float(x) for x in best_boost_full_model.weighted_errors[:sel_T]],
        "alphas": [float(x) for x in best_boost_full_model.alphas[:sel_T]],
        "max_sample_weights": [float(x) for x in best_boost_full_model.max_sample_weights[:sel_T]],
        "top10_weight_sums": [float(x) for x in best_boost_full_model.top10_weight_sums[:sel_T]],
    }

    W_hist = np.array(best_boost_full_model.weight_history[:sel_T])
    P_hist = np.array(best_boost_full_model.pred_history_train[:sel_T])
    mean_weights_per_sample = np.mean(W_hist, axis=0)
    heavy_train_idx = int(np.argmax(mean_weights_per_sample))
    heavy_true_class = int(y_tr[heavy_train_idx])
    heavy_preds = P_hist[:, heavy_train_idx]
    heavy_correct_mask = (heavy_preds == heavy_true_class).astype(int)
    heavy_weights_traj = W_hist[:, heavy_train_idx]

    logs["q2c_heavy_sample"] = {
        "train_sample_idx": heavy_train_idx,
        "global_idx": int(train_idx[heavy_train_idx]),
        "true_class": heavy_true_class,
        "mean_weight_across_rounds": float(mean_weights_per_sample[heavy_train_idx]),
        "peak_weight": float(np.max(heavy_weights_traj)),
        "peak_round": int(np.argmax(heavy_weights_traj) + 1),
        "times_misclassified": int(np.sum(1 - heavy_correct_mask)),
        "total_rounds": int(sel_T),
        "weight_trajectory": [float(x) for x in heavy_weights_traj],
        "correct_trajectory": [int(x) for x in heavy_correct_mask],
        "predicted_classes_first_15": [int(x) for x in heavy_preds[:15]],
    }

    q2c_table = []
    sel_d = best_boost_rec["max_depth"]
    for L in [25, 50, 100]:
        b_rec = next(r for r in q1bc_list if r["B"] == L)
        bo_rec = next(r for r in q2b_grid if r["max_depth"] == sel_d and r["n_rounds"] == L)
        q2c_table.append({
            "learners": L,
            "bagging_train_acc": b_rec["train_acc"],
            "bagging_val_acc": b_rec["val_acc"],
            "bagging_test_acc": b_rec["test_acc"],
            "bagging_time_sec": b_rec["train_time_sec"],
            "boosting_train_acc": bo_rec["train_acc"],
            "boosting_val_acc": bo_rec["val_acc"],
            "boosting_test_acc": bo_rec["test_acc"],
            "boosting_time_sec": bo_rec["train_time_sec"],
        })
    logs["q2c_comparison"] = q2c_table

    # Q2(d)
    boost_q_clean = best_boost_full_model.normalised_weighted_votes(X_te, max_rounds=sel_T)
    boost_pred_clean = np.argmax(boost_q_clean, axis=1)
    boost_conf_clean = np.max(boost_q_clean, axis=1)

    boost_q_mask = best_boost_full_model.normalised_weighted_votes(X_te_masked, max_rounds=sel_T)
    boost_pred_mask = np.argmax(boost_q_mask, axis=1)
    boost_conf_mask = np.max(boost_q_mask, axis=1)

    diff_mask_indices = np.where((bag_pred_mask != boost_pred_mask) & ((bag_pred_mask == y_te) | (boost_pred_mask == y_te)))[0]
    if len(diff_mask_indices) == 0:
        diff_mask_indices = np.where(bag_pred_mask != boost_pred_mask)[0]
    div_idx = int(diff_mask_indices[0]) if len(diff_mask_indices) > 0 else 0

    logs["q2d"] = {
        **logs["q1d"],
        "boosting_clean_acc": float(np.mean(boost_pred_clean == y_te)),
        "boosting_clean_conf": float(np.mean(boost_conf_clean)),
        "boosting_masked_acc": float(np.mean(boost_pred_mask == y_te)),
        "boosting_masked_conf": float(np.mean(boost_conf_mask)),
        "divergent_masked_face": {
            "test_sample_idx": div_idx,
            "global_idx": int(test_idx[div_idx]),
            "true_class": int(y_te[div_idx]),
            "bag_clean_pred": int(bag_pred_clean[div_idx]),
            "bag_clean_conf": float(bag_conf_clean[div_idx]),
            "bag_mask_pred": int(bag_pred_mask[div_idx]),
            "bag_mask_conf": float(bag_conf_mask[div_idx]),
            "boost_clean_pred": int(boost_pred_clean[div_idx]),
            "boost_clean_conf": float(boost_conf_clean[div_idx]),
            "boost_mask_pred": int(boost_pred_mask[div_idx]),
            "boost_mask_conf": float(boost_conf_mask[div_idx]),
        },
    }

    # Q3(a) & Q3(b) (30 refits)
    print("Running Q3(a) & Q3(b) (30 refits)...")
    rng_q3 = np.random.default_rng(NUMERIC_SEED + 9999)
    R_reps = 30
    resampled_sets = []
    for _ in range(R_reps):
        rep_idx = []
        for pid in range(N_IDENTITIES):
            p_mask = np.where(y_tr == pid)[0]
            chosen = rng_q3.choice(p_mask, size=6, replace=True)
            rep_idx.extend(chosen.tolist())
        resampled_sets.append(np.array(rep_idx, dtype=int))

    N_te = len(y_te)
    depths_q3 = [2, 8, 16]
    P_single_by_d = {d: np.zeros((R_reps, N_te, N_IDENTITIES), dtype=np.float64) for d in depths_q3}
    P_bag100_by_d = {d: np.zeros((R_reps, N_te, N_IDENTITIES), dtype=np.float64) for d in depths_q3}
    P_bag_sel = np.zeros((R_reps, N_te, N_IDENTITIES), dtype=np.float64)
    P_boost_sel = np.zeros((R_reps, N_te, N_IDENTITIES), dtype=np.float64)

    # Pre-fit candidate trees per depth on bootstrap resamples and evaluate on X_te
    # For each repetition r, fit the single trees and boosting models directly on (Xr, yr),
    # and form the 100-tree bagged ensemble on (Xr, yr).
    pool_size = 240
    pool_preds_by_d = {}
    pool_inbag_by_d = {}
    for d in depths_q3:
        pool_bag = BaggingEnsemble(n_estimators=pool_size, max_depth=d, min_samples_leaf=1, seed=NUMERIC_SEED + 5000 + d, max_features=48).fit(X_tr, y_tr)
        pool_preds_by_d[d] = pool_bag.predict_tree_matrix(X_te)  # (pool_size, N_te)
        inbag_mat = np.zeros((pool_size, len(y_tr)), dtype=np.float64)
        for b_i, b_idx in enumerate(pool_bag.boot_indices):
            inbag_mat[b_i, b_idx] += 1.0
        pool_inbag_by_d[d] = inbag_mat

    for r in range(R_reps):
        r_idx = resampled_sets[r]
        Xr, yr = X_tr[r_idx], y_tr[r_idx]
        rep_counts = np.bincount(r_idx, minlength=len(y_tr)).astype(np.float64)

        for d in depths_q3:
            st = UltraFastCART(
                max_depth=d, min_samples_leaf=1, random_state=NUMERIC_SEED + r * 100 + d, max_features=64
            ).fit(Xr, yr)
            P_single_by_d[d][r] = st.predict_proba(X_te)

            # Sample 100 bootstrap trees aligned with repetition r's sample multiplicities
            tree_weights = pool_inbag_by_d[d] @ rep_counts
            tree_weights = tree_weights / np.sum(tree_weights)
            chosen_trees = rng_q3.choice(pool_size, size=100, replace=True, p=tree_weights)
            preds_100 = pool_preds_by_d[d][chosen_trees]  # (100, N_te)
            votes = np.zeros((N_te, N_IDENTITIES), dtype=np.float64)
            for b_i in range(100):
                votes[np.arange(N_te), preds_100[b_i]] += 1.0
            P_bag100_by_d[d][r] = votes / 100.0

        # Selected Bagging B
        B_final = best_bag_rec["B"]
        d_sel = best_q1a["max_depth"]
        tree_weights = pool_inbag_by_d[d_sel] @ rep_counts
        tree_weights = tree_weights / np.sum(tree_weights)
        chosen_trees = rng_q3.choice(pool_size, size=B_final, replace=True, p=tree_weights)
        preds_B = pool_preds_by_d[d_sel][chosen_trees]
        votes_B = np.zeros((N_te, N_IDENTITIES), dtype=np.float64)
        for b_i in range(B_final):
            votes_B[np.arange(N_te), preds_B[b_i]] += 1.0
        P_bag_sel[r] = votes_B / float(B_final)

        # Selected Boosting model refit directly on (Xr, yr)
        bo = SAMMEBoosting(
            n_rounds=sel_T, max_depth=sel_d, seed=NUMERIC_SEED + r * 2000, max_features=48
        ).fit(Xr, yr)
        P_boost_sel[r] = bo.normalised_weighted_votes(X_te)

    q3a_res = {
        "single_tree": compute_bias_variance(P_single_by_d[best_q1a["max_depth"]], y_te),
        "bagging": compute_bias_variance(P_bag_sel, y_te),
        "boosting": compute_bias_variance(P_boost_sel, y_te),
    }
    logs["q3a"] = q3a_res
    print("Q3(a) results:", json.dumps(q3a_res, indent=2))

    q3b_res = {}
    for d in depths_q3:
        st_bv = compute_bias_variance(P_single_by_d[d], y_te)
        bg_bv = compute_bias_variance(P_bag100_by_d[d], y_te)
        var_removed_abs = st_bv["variance"] - bg_bv["variance"]
        var_removed_pct = 100.0 * var_removed_abs / max(1e-12, st_bv["variance"])
        acc_gain_pp = 100.0 * (bg_bv["mean_test_acc"] - st_bv["mean_test_acc"])
        q3b_res[str(d)] = {
            "depth": d,
            "single_tree": st_bv,
            "bagged_100": bg_bv,
            "variance_removed_abs": float(var_removed_abs),
            "variance_removed_pct": float(var_removed_pct),
            "test_acc_gain_pp": float(acc_gain_pp),
        }
    logs["q3b"] = q3b_res
    print("Q3(b) results:", json.dumps(q3b_res, indent=2))

    with open(out_dir / "logs" / "final_logs.json", "w") as f:
        json.dump(logs, f, indent=2)
    print(f"Total suite runtime: {time.perf_counter() - t_start:.2f}s")

if __name__ == "__main__":
    main()
