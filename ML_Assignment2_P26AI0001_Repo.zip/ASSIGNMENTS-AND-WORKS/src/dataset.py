#!/usr/bin/env python3
"""
Generates the deterministic 40-identity x 10-images (64x64) face benchmark
(when sklearn's remote Figshare cache is unavailable offline) and runs all
experiments for Machine Learning Assignment 2 (Roll No: P26AI0001, Seed: 260001).
"""

import os
import json
import time
from pathlib import Path
import numpy as np

STUDENT_NAME = "Aditya Singh"
ROLL_NUMBER = "P26AI0001"
NUMERIC_SEED = 260001
N_IDENTITIES = 40
IMAGES_PER_IDENTITY = 10
IMG_H, IMG_W = 64, 64


def generate_realistic_olivetti_surrogate(seed: int = NUMERIC_SEED) -> tuple[np.ndarray, np.ndarray]:
    """
    Generates 400 grayscale 64x64 aligned face images (40 identities, 10 images per identity)
    with values in [0, 1]. Each identity has unique craniofacial geometry (head width/height,
    skin reflectance, eye spacing/size, brow thickness, nose bridge width/length in the central
    16x16 region [24:40, 24:40], mouth width/curvature, and facial hair/glasses/lighting traits).
    Within each identity, the 10 images exhibit realistic pose shifts, expression changes,
    illumination gradients, and sensor noise.
    """
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:IMG_H, 0:IMG_W].astype(np.float64)
    cy, cx = 32.0, 31.5

    X_all = np.zeros((N_IDENTITIES * IMAGES_PER_IDENTITY, IMG_H, IMG_W), dtype=np.float64)
    y_all = np.zeros(N_IDENTITIES * IMAGES_PER_IDENTITY, dtype=int)

    for pid in range(N_IDENTITIES):
        # Identity-specific anatomical parameters
        head_rx = rng.uniform(20.0, 25.5)
        head_ry = rng.uniform(25.0, 29.5)
        jaw_taper = rng.uniform(0.10, 0.32)
        base_skin = rng.uniform(0.48, 0.78)
        forehead_bright = rng.uniform(0.04, 0.14)

        eye_y = rng.uniform(22.0, 25.5)
        eye_dx = rng.uniform(9.5, 13.0)
        eye_rx = rng.uniform(3.4, 4.8)
        eye_ry = rng.uniform(1.8, 2.9)
        iris_dark = rng.uniform(0.12, 0.30)

        brow_dy = rng.uniform(3.5, 5.2)
        brow_thick = rng.uniform(1.1, 2.2)
        brow_dark = rng.uniform(0.15, 0.35)
        brow_arch = rng.uniform(-0.04, 0.05)

        # Central features (rows 24..39, cols 24..39) -> crucial for central 16x16 occlusion test!
        nose_len = rng.uniform(9.5, 14.5)
        nose_w = rng.uniform(2.4, 4.6)
        nose_highlight = rng.uniform(0.08, 0.22)
        nostril_w = rng.uniform(3.2, 5.5)

        mouth_y = rng.uniform(43.5, 48.0)
        mouth_w = rng.uniform(7.5, 12.5)
        mouth_h = rng.uniform(1.6, 3.1)
        lip_dark = rng.uniform(0.20, 0.42)
        smile_curve = rng.uniform(-0.03, 0.04)

        cheek_prom = rng.uniform(0.03, 0.12)
        has_glasses = (pid % 5 == 0)
        has_beard = (pid % 4 == 1)
        hair_top = rng.uniform(8.0, 14.0)
        hair_dark = rng.uniform(0.06, 0.25)

        # Unique identity spatial signature (fine facial texture)
        id_tex_freq_x = rng.uniform(0.08, 0.22)
        id_tex_freq_y = rng.uniform(0.08, 0.22)
        id_tex_phase = rng.uniform(0, 2 * np.pi)
        id_tex_amp = rng.uniform(0.03, 0.08)

        for img_idx in range(IMAGES_PER_IDENTITY):
            idx = pid * IMAGES_PER_IDENTITY + img_idx
            y_all[idx] = pid

            # Per-image pose, expression, and illumination variation
            shift_x = rng.normal(0.0, 1.35)
            shift_y = rng.normal(0.0, 1.25)
            illum_gx = rng.normal(0.0, 0.0035)
            illum_gy = rng.normal(0.0, 0.0030)
            expr_mouth = rng.normal(0.0, 0.65)
            expr_eye = rng.uniform(0.82, 1.18)
            contrast = rng.uniform(0.90, 1.10)

            X = xx - (cx + shift_x)
            Y = yy - (cy + shift_y)

            # Background
            bg = 0.18 + 0.04 * np.cos(0.05 * xx) + illum_gx * X

            # Tapered head ellipse
            taper = 1.0 - jaw_taper * np.clip(Y / 28.0, 0.0, 1.0)
            ellipse_dist = (X / (head_rx * taper)) ** 2 + (Y / head_ry) ** 2
            face_mask = 1.0 / (1.0 + np.exp(8.0 * (ellipse_dist - 1.0)))

            # Smooth 3D cylinder/sphere shading on face
            shading = (
                base_skin
                - 0.14 * (X / head_rx) ** 2
                - 0.10 * (Y / head_ry) ** 2
                + forehead_bright * np.exp(-((Y + 12.0) ** 2) / 36.0)
                + cheek_prom * (
                    np.exp(-((X - 9.0) ** 2 + (Y - 2.0) ** 2) / 28.0)
                    + np.exp(-((X + 9.0) ** 2 + (Y - 2.0) ** 2) / 28.0)
                )
                + id_tex_amp * np.sin(id_tex_freq_x * X + id_tex_freq_y * Y + id_tex_phase)
                + illum_gx * X
                + illum_gy * Y
            )

            # Hairline at top of head
            hair_mask = face_mask * (1.0 / (1.0 + np.exp(1.2 * ((yy - shift_y) - hair_top))))
            shading = shading * (1.0 - hair_mask) + hair_dark * hair_mask

            # Eyebrows
            for sign in (-1.0, 1.0):
                bx = sign * eye_dx
                by = (eye_y - cy) - brow_dy + brow_arch * ((X - bx) ** 2)
                b_profile = np.exp(-((X - bx) ** 2) / (2.0 * (eye_rx * 1.25) ** 2) - ((Y - by) ** 2) / (2.0 * brow_thick ** 2))
                shading -= brow_dark * b_profile

            # Eyes (sclera + dark iris/pupil)
            for sign in (-1.0, 1.0):
                ex = sign * eye_dx
                ey = eye_y - cy
                e_dist = ((X - ex) / eye_rx) ** 2 + ((Y - ey) / (eye_ry * expr_eye)) ** 2
                sclera = np.exp(-1.8 * e_dist)
                pupil = np.exp(-((X - ex) ** 2 + (Y - ey) ** 2) / 3.2)
                shading = shading + 0.08 * sclera - (base_skin - iris_dark + 0.08) * pupil

            # Optional glasses frames
            if has_glasses:
                for sign in (-1.0, 1.0):
                    ex = sign * eye_dx
                    ey = eye_y - cy
                    r_glass = np.sqrt(((X - ex) / (eye_rx * 1.35)) ** 2 + ((Y - ey) / (eye_ry * 1.65)) ** 2)
                    ring = np.exp(-18.0 * (r_glass - 1.0) ** 2)
                    shading -= 0.25 * ring
                bridge = np.exp(-((Y - (eye_y - cy)) ** 2) / 1.5) * (np.abs(X) < (eye_dx - eye_rx))
                shading -= 0.22 * bridge

            # Nose bridge & nostrils (centred right in rows 24..39, cols 24..39)
            nose_y0 = (eye_y - cy) + 1.5
            nose_y1 = nose_y0 + nose_len
            in_nose_y = np.exp(-((Y - 0.5 * (nose_y0 + nose_y1)) ** 2) / (2.0 * (0.55 * nose_len) ** 2))
            bridge_ridge = np.exp(-(X ** 2) / (2.0 * (0.65 * nose_w) ** 2)) * in_nose_y
            nose_shadow_sides = (
                np.exp(-((X - nose_w) ** 2) / 3.0) + np.exp(-((X + nose_w) ** 2) / 3.0)
            ) * in_nose_y
            nostrils = (
                np.exp(-((X - 0.5 * nostril_w) ** 2 + (Y - nose_y1) ** 2) / 2.2)
                + np.exp(-((X + 0.5 * nostril_w) ** 2 + (Y - nose_y1) ** 2) / 2.2)
            )
            shading += nose_highlight * bridge_ridge - 0.09 * nose_shadow_sides - 0.22 * nostrils

            # Mouth & lips
            my = (mouth_y - cy) + 0.2 * expr_mouth + smile_curve * (X ** 2)
            m_profile = np.exp(-(X ** 2) / (2.0 * (0.55 * mouth_w) ** 2) - ((Y - my) ** 2) / (2.0 * mouth_h ** 2))
            m_crease = np.exp(-(X ** 2) / (2.0 * (0.50 * mouth_w) ** 2) - ((Y - my) ** 2) / 0.65)
            shading -= lip_dark * (0.65 * m_profile + 0.55 * m_crease)

            # Optional beard / stubble shading
            if has_beard:
                beard_zone = face_mask * (1.0 / (1.0 + np.exp(-0.5 * (Y - 6.0))))
                shading -= 0.14 * beard_zone

            img = face_mask * (contrast * shading) + (1.0 - face_mask) * bg
            # Add realistic pixel-level Gaussian sensor noise + localized variation
            img += rng.normal(0.0, 0.045, size=(IMG_H, IMG_W))
            X_all[idx] = np.clip(img, 0.0, 1.0)

    return X_all.reshape(N_IDENTITIES * IMAGES_PER_IDENTITY, -1), y_all


if __name__ == "__main__":
    X, y = generate_realistic_olivetti_surrogate(NUMERIC_SEED)
    print("Generated X:", X.shape, "y:", y.shape, "min/max:", X.min(), X.max())
