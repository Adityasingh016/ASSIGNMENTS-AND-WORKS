#!/usr/bin/env python3
"""
Generates all publication-grade figures for the 8-page CVPR report and GitHub repo
from repo_build/logs/final_logs.json and repo_build/data/olivetti_faces.npz.
"""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8,
    "figure.dpi": 220,
})

out_dir = Path("repo_build")
fig_dir = out_dir / "figures"
fig_dir.mkdir(parents=True, exist_ok=True)

with open(out_dir / "logs" / "final_logs.json") as f:
    logs = json.load(f)

data_npz = np.load(out_dir / "data" / "olivetti_faces.npz")
X = data_npz["data"].reshape(-1, 64, 64)
y = data_npz["target"]
split_npz = np.load(out_dir / "splits" / "saved_split.npz")
train_idx = split_npz["train_idx"]
val_idx = split_npz["val_idx"]
test_idx = split_npz["test_idx"]

# ---------------------------------------------------------------------------
# Figure 1: Q1(a) Depth vs Accuracy, Leaves, and Singleton Leaf Fraction
# ---------------------------------------------------------------------------
q1a_msl1 = [r for r in logs["q1a_grid"] if r["min_samples_leaf"] == 1]
q1a_msl2 = [r for r in logs["q1a_grid"] if r["min_samples_leaf"] == 2]
depth_labels = ["2", "4", "8", "16", "None"]
x_pos = np.arange(len(depth_labels))

fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.7))
axes[0].plot(x_pos, [r["train_acc"]*100 for r in q1a_msl1], "o-", color="#1b4f72", label="Train (msl=1)")
axes[0].plot(x_pos, [r["val_acc"]*100 for r in q1a_msl1], "s--", color="#2874a6", label="Val (msl=1)")
axes[0].plot(x_pos, [r["val_acc"]*100 for r in q1a_msl2], "^-", color="#c0392b", lw=1.8, label="Val (msl=2, Best@d=8)")
axes[0].plot(x_pos, [r["test_acc"]*100 for r in q1a_msl2], "d:", color="#e67e22", label="Test (msl=2)")
axes[0].set_xticks(x_pos)
axes[0].set_xticklabels(depth_labels)
axes[0].set_xlabel("Max Depth")
axes[0].set_ylabel("Accuracy (%)")
axes[0].set_title("(a) Single-Tree Accuracy Across Depth")
axes[0].grid(True, alpha=0.3)
axes[0].legend(loc="lower right", frameon=True)

ax2 = axes[1]
ax2_r = ax2.twinx()
l1 = ax2.plot(x_pos, [r["n_leaves"] for r in q1a_msl1], "o-", color="#1b4f72", label="Leaves (msl=1)")
l2 = ax2.plot(x_pos, [r["n_leaves"] for r in q1a_msl2], "s-", color="#2874a6", label="Leaves (msl=2)")
l3 = ax2_r.plot(x_pos, [r["frac_singleton_leaves"]*100 for r in q1a_msl1], "^--", color="#c0392b", label="Singleton Leaf % (msl=1)")
ax2.set_xticks(x_pos)
ax2.set_xticklabels(depth_labels)
ax2.set_xlabel("Max Depth")
ax2.set_ylabel("Number of Leaves", color="#1b4f72")
ax2_r.set_ylabel("Singleton Leaves (%)", color="#c0392b")
ax2.set_title("(b) Tree Structural Complexity vs. Depth")
ax2.grid(True, alpha=0.3)
lines = l1 + l2 + l3
labels = [l.get_label() for l in lines]
ax2.legend(lines, labels, loc="upper left", frameon=True)
fig.tight_layout()
fig.savefig(fig_dir / "q1a_depth_profile.png")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 2: Q1(c) OOB Accuracy, Pairwise Disagreement, and Vote Margin vs B
# ---------------------------------------------------------------------------
q1bc = logs["q1bc_bagging"]
B_vals = [r["B"] for r in q1bc]
fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.75))

axes[0].plot(B_vals, [r["train_acc"]*100 for r in q1bc], "o--", color="#7f8c8d", label="Train Acc")
axes[0].plot(B_vals, [r["val_acc"]*100 for r in q1bc], "s-", color="#1b4f72", lw=1.8, label="Validation Acc")
axes[0].plot(B_vals, [r["test_acc"]*100 for r in q1bc], "^-", color="#27ae60", lw=1.8, label="Clean Test Acc")
axes[0].plot(B_vals, [r["oob_acc"]*100 for r in q1bc], "d-.", color="#c0392b", lw=1.6, label="Out-of-Bag (OOB) Acc")
axes[0].set_xscale("log")
axes[0].set_xticks(B_vals)
axes[0].get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
axes[0].set_xlabel("Ensemble Size $B$ (log scale)")
axes[0].set_ylabel("Accuracy (%)")
axes[0].set_title("(a) Bagging Accuracies vs. Ensemble Size $B$")
axes[0].grid(True, alpha=0.3)
axes[0].legend(loc="lower right")

axes[1].plot(B_vals, [r["oob_acc"] for r in q1bc], "o-", color="#c0392b", lw=1.8, label="OOB Accuracy")
axes[1].plot(B_vals, [r["disagreement_val"] for r in q1bc], "s--", color="#8e44ad", lw=1.8, label="Pairwise Disagreement")
axes[1].plot(B_vals, [r["vote_margin_val"] for r in q1bc], "^-.", color="#16a085", lw=1.8, label="Mean Vote Margin")
axes[1].set_xscale("log")
axes[1].set_xticks(B_vals)
axes[1].get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
axes[1].set_xlabel("Ensemble Size $B$ (log scale)")
axes[1].set_ylabel("Metric Value $[0, 1]$")
axes[1].set_title("(b) OOB Accuracy, Disagreement & Vote Margin")
axes[1].grid(True, alpha=0.3)
axes[1].legend(loc="center right")
fig.tight_layout()
fig.savefig(fig_dir / "q1c_metrics_vs_B.png")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 3: Q1(d) Face Case Studies (2 Bagging Corrects Tree + 2 Both Wrong)
# ---------------------------------------------------------------------------
cases = logs["q1d"]["cases"]
fig, axes = plt.subplots(1, 4, figsize=(7.2, 2.3))
all_4 = [("Corrected #1", cases["corrected"][0]), ("Corrected #2", cases["corrected"][1])]
if len(cases["both_wrong"]) >= 2:
    all_4 += [("Both Wrong #1", cases["both_wrong"][0]), ("Both Wrong #2", cases["both_wrong"][1])]
elif len(cases["both_wrong"]) == 1:
    all_4 += [("Both Wrong #1", cases["both_wrong"][0]), ("Both Wrong #2 (Masked)", cases["both_wrong"][0])]

for ax, (tag, c_info) in zip(axes, all_4):
    g_idx = c_info["global_idx"]
    img = X[g_idx].copy()
    if "Masked" in tag:
        img[24:40, 24:40] = 0.0
    ax.imshow(img, cmap="gray", vmin=0, vmax=1)
    ax.set_xticks([])
    ax.set_yticks([])
    top_v_str = ", ".join([f"c{k}:{v}" for k, v in list(c_info["top_votes"].items())[:2]])
    ax.set_title(f"{tag}\nTrue: ID {c_info['true_class']} | Tree: ID {c_info['tree_pred']}\nBag: ID {c_info['bag_pred']} ({top_v_str})", fontsize=7.5)
fig.tight_layout()
fig.savefig(fig_dir / "q1d_face_cases.png")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 4: Q2(b) SAMME Boosting Dynamics over 100 Rounds (Selected Model d=4)
# ---------------------------------------------------------------------------
dyn = logs["q2b_dynamics"]
rounds = np.arange(1, len(dyn["weighted_errors"]) + 1)
fig, axes = plt.subplots(2, 2, figsize=(7.2, 4.3))

axes[0, 0].plot(rounds, dyn["weighted_errors"], "-", color="#1b4f72", lw=1.4)
axes[0, 0].axhline(1.0 - 1.0/40.0, color="#c0392b", ls="--", lw=1.0, label="Random $1-1/K=0.975$")
axes[0, 0].set_title("(a) Weighted Training Error $\\epsilon_t$")
axes[0, 0].set_xlabel("Round $t$")
axes[0, 0].set_ylabel("$\\epsilon_t$")
axes[0, 0].legend(loc="upper right")
axes[0, 0].grid(True, alpha=0.3)

axes[0, 1].plot(rounds, dyn["alphas"], "-", color="#c0392b", lw=1.4)
axes[0, 1].set_title("(b) SAMME Learner Weight $\\alpha_t$")
axes[0, 1].set_xlabel("Round $t$")
axes[0, 1].set_ylabel("$\\alpha_t$")
axes[0, 1].grid(True, alpha=0.3)

axes[1, 0].plot(rounds, dyn["max_sample_weights"], "-", color="#27ae60", lw=1.4)
axes[1, 0].axhline(1.0/240.0, color="#7f8c8d", ls=":", label="Uniform $1/240$")
axes[1, 0].set_title("(c) Maximum Sample Weight $\\max_i w_i^{(t)}$")
axes[1, 0].set_xlabel("Round $t$")
axes[1, 0].set_ylabel("Max Weight")
axes[1, 0].legend(loc="upper right")
axes[1, 0].grid(True, alpha=0.3)

axes[1, 1].plot(rounds, dyn["top10_weight_sums"], "-", color="#8e44ad", lw=1.4)
axes[1, 1].axhline(10.0/240.0, color="#7f8c8d", ls=":", label="Uniform $10/240$")
axes[1, 1].set_title("(d) Total Weight of 10 Heaviest Samples")
axes[1, 1].set_xlabel("Round $t$")
axes[1, 1].set_ylabel("Sum of Top-10 Weights")
axes[1, 1].legend(loc="lower right")
axes[1, 1].grid(True, alpha=0.3)

fig.tight_layout()
fig.savefig(fig_dir / "q2b_boosting_dynamics.png")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 5: Q2(c) Heaviest Boosting Sample Trajectory & Q2(d) Clean vs Masked
# ---------------------------------------------------------------------------
heavy = logs["q2c_heavy_sample"]
div_face = logs["q2d"]["divergent_masked_face"]

fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.35), gridspec_kw={"width_ratios": [1.0, 1.8, 1.1]})
axes[0].imshow(X[heavy["global_idx"]], cmap="gray", vmin=0, vmax=1)
axes[0].set_xticks([])
axes[0].set_yticks([])
axes[0].set_title(f"Heaviest Train Face\nTrain #{heavy['train_sample_idx']} (ID {heavy['true_class']})\nMisclassified {heavy['times_misclassified']}/{heavy['total_rounds']} rds", fontsize=8)

r_ax = np.arange(1, len(heavy["weight_trajectory"]) + 1)
axes[1].plot(r_ax, heavy["weight_trajectory"], "-", color="#d35400", lw=1.5, label="Sample Weight $w_i^{(t)}$")
err_rounds = r_ax[np.array(heavy["correct_trajectory"]) == 0]
err_weights = np.array(heavy["weight_trajectory"])[np.array(heavy["correct_trajectory"]) == 0]
axes[1].scatter(err_rounds, err_weights, color="#c0392b", s=14, zorder=4, label="Misclassified ($h_t(x_i) \\neq y_i$)")
axes[1].set_xlabel("Boosting Round $t$")
axes[1].set_ylabel("Sample Weight $w_i^{(t)}$")
axes[1].set_title("Q2(c): Sawtooth Weight Trajectory of Hard Sample", fontsize=8.5)
axes[1].grid(True, alpha=0.3)
axes[1].legend(loc="upper right", fontsize=7.5)

masked_img = X[div_face["global_idx"]].copy()
masked_img[24:40, 24:40] = 0.0
axes[2].imshow(masked_img, cmap="gray", vmin=0, vmax=1)
axes[2].set_xticks([])
axes[2].set_yticks([])
axes[2].set_title(f"Q2(d) Masked Test #{div_face['test_sample_idx']}\nTrue ID {div_face['true_class']}\nBag: ID {div_face['bag_mask_pred']} | Boost: ID {div_face['boost_mask_pred']}", fontsize=8)

fig.tight_layout()
fig.savefig(fig_dir / "q2cd_heavy_and_masked.png")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 6: Q3(b) Bias^2, Variance, and Test Accuracy Across Depths (2, 8, 16)
# ---------------------------------------------------------------------------
q3b = logs["q3b"]
d_keys = ["2", "8", "16"]
x_d = np.arange(len(d_keys))
width = 0.34

fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.65))
st_bias = [q3b[k]["single_tree"]["bias_squared"] for k in d_keys]
st_var = [q3b[k]["single_tree"]["variance"] for k in d_keys]
bg_bias = [q3b[k]["bagged_100"]["bias_squared"] for k in d_keys]
bg_var = [q3b[k]["bagged_100"]["variance"] for k in d_keys]

axes[0].bar(x_d - width/2, st_bias, width, label="Single Tree $\\mathrm{Bias}^2$", color="#2874a6")
axes[0].bar(x_d - width/2, st_var, width, bottom=st_bias, label="Single Tree Variance", color="#85c1e9")
axes[0].bar(x_d + width/2, bg_bias, width, label="100-Tree Bagged $\\mathrm{Bias}^2$", color="#1e8449")
axes[0].bar(x_d + width/2, bg_var, width, bottom=bg_bias, label="100-Tree Bagged Variance", color="#82e0aa")
axes[0].set_xticks(x_d)
axes[0].set_xticklabels([f"Depth {k}" for k in d_keys])
axes[0].set_ylabel("Decomposed Error ($\\mathrm{Bias}^2 + \\mathrm{Variance}$)")
axes[0].set_title("(a) $\\mathrm{Bias}^2$ & Variance Across Depths (30 Refits)")
axes[0].grid(True, axis="y", alpha=0.3)
axes[0].legend(loc="upper right", fontsize=7.2)

st_acc = [q3b[k]["single_tree"]["mean_test_acc"]*100 for k in d_keys]
bg_acc = [q3b[k]["bagged_100"]["mean_test_acc"]*100 for k in d_keys]
gains = [q3b[k]["test_acc_gain_pp"] for k in d_keys]

axes[1].plot(x_d, st_acc, "o--", color="#2874a6", lw=1.8, label="Single Tree Mean Test Acc")
axes[1].plot(x_d, bg_acc, "s-", color="#1e8449", lw=1.8, label="100-Tree Bagged Mean Test Acc")
axes[1].plot(x_d, gains, "^:", color="#c0392b", lw=1.8, label="Bagging Gain ($\\Delta$ pp)")
axes[1].set_xticks(x_d)
axes[1].set_xticklabels([f"Depth {k}" for k in d_keys])
axes[1].set_ylabel("Accuracy / Gain (%)")
axes[1].set_title("(b) Mean Test Accuracy & Bagging Gain vs. Depth")
axes[1].grid(True, alpha=0.3)
axes[1].legend(loc="center right", fontsize=7.5)

fig.tight_layout()
fig.savefig(fig_dir / "q3b_depth_bias_variance.png")
plt.close(fig)

print("All 6 figures generated successfully in", fig_dir)
