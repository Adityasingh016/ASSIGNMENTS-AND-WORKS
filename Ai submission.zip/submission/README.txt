AI Assignment: General-Purpose Classical AI Reasoning System
Name: Aditya Singh
Roll No.: P26AI0001

1. Directory Structure
----------------------
submission/
|-- reasoning_agent.ipynb   : Complete implementation, dataset evaluation,
|                             reasoning traces, and submission.csv generator.
|-- report.pdf              : Report describing the internal representation,
|                             classical reasoning algorithms, public dataset
|                             experiments, and step-by-step reasoning traces.
|-- submission.csv          : Generated predictions (columns: id, label) with
|                             True/False logical entailment flags.
`-- README.txt              : Setup and usage instructions.

2. Requirements
---------------
- Python 3.9+
- Standard Python libraries for the core reasoning engine:
  re, time, heapq, csv, json, dataclasses, typing
- Optional libraries for plotting and Hugging Face dataset loading:
  numpy, pandas, matplotlib, datasets

3. Overview of the Pipeline
---------------------------
Natural Language Knowledge Base -> NLToLogicParser -> KnowledgeBase
(Facts, Horn/Normal Rules, CNF Clauses, Causal Equations, Equalities)
-> ClassicalReasoningSystem -> True / False Prediction + Derivation Trace

Implemented Classical Reasoning Algorithms:
1. ForwardChainingEngine:
   - Unification-based forward chaining with Modus Tollens, equality
     substitution, and two-stratum Negation-as-Failure (for closed-world
     RuleTaker theories).
2. BackwardChainingSearchEngine:
   - Goal-directed backward search over AND-OR subgoal stacks supporting
     Depth-First Search (DFS), Breadth-First Search (BFS), and A* Search
     (f(n) = g(n) + h(n), where h(n) counts unsatisfied subgoals).
3. ResolutionProver:
   - Conjunctive Normal Form (CNF) resolution refutation with unit-preference
     best-first search.
4. CausalCounterfactualEngine:
   - 3-step counterfactual evaluation (Abduction, do-calculus Intervention,
     and forward propagation) for CounterBench causal graphs.

4. Running the Notebook & Generating submission.csv
---------------------------------------------------
To run the full notebook:
  jupyter nbconvert --to notebook --execute reasoning_agent.ipynb

To generate predictions on an external test file (CSV or JSON/JSONL with
columns id, context, question/query/statement):
  generate_submission_csv(
      input_data_or_path="path/to/private_test.csv",
      output_path="submission.csv"
  )
