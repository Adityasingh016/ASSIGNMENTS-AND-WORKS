#!/usr/bin/env python3
"""
PyTorch Model Definitions for ML Assignment 3 (CIFAR-10)
Author: Aditya Singh (Roll No: P26AI0001, Seed: 260001)
Verifies exact architectural specifications and parameter budgets across Q1, Q2, and Q3.
"""
try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

if TORCH_AVAILABLE:
    class MLPShallowWide(nn.Module):
        """Q1(a) Baseline 2-Layer Unnormalized MLP: 3072 -> 256 -> 10 (789,258 params)"""
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(
                nn.Flatten(),
                nn.Linear(3072, 256),
                nn.ReLU(inplace=True),
                nn.Linear(256, 10),
            )
        def forward(self, x):
            return self.net(x)

    class MLPDeepUnnorm(nn.Module):
        """Q1(a) 4-Layer Unnormalized MLP: 3072 -> 224 -> 256 -> 160 -> 10 (788,682 params)"""
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(
                nn.Flatten(),
                nn.Linear(3072, 224),
                nn.ReLU(inplace=True),
                nn.Linear(224, 256),
                nn.ReLU(inplace=True),
                nn.Linear(256, 160),
                nn.ReLU(inplace=True),
                nn.Linear(160, 10),
            )
        def forward(self, x):
            return self.net(x)

    class MLPDeepBNReg(nn.Module):
        """Q1(a) & Q2(a) 4-Layer Batch-Normalized MLP: 3072 -> 224 -> 256 -> 160 -> 10 (789,962 params)"""
        def __init__(self, dropout_p=0.2):
            super().__init__()
            self.net = nn.Sequential(
                nn.Flatten(),
                nn.Linear(3072, 224),
                nn.BatchNorm1d(224),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout_p),
                nn.Linear(224, 256),
                nn.BatchNorm1d(256),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout_p),
                nn.Linear(256, 160),
                nn.BatchNorm1d(160),
                nn.ReLU(inplace=True),
                nn.Linear(160, 10),
            )
        def forward(self, x):
            return self.net(x)

    class MLPPatchToken(nn.Module):
        """Q1(a) Local 4x4 Patch-Token MLP: 64x(48->32) + 2048->320->392->10 (788,498 params)"""
        def __init__(self):
            super().__init__()
            self.patch_proj = nn.Linear(48, 32)
            self.patch_bn = nn.BatchNorm1d(32)
            self.mixer = nn.Sequential(
                nn.Linear(2048, 320),
                nn.BatchNorm1d(320),
                nn.ReLU(inplace=True),
                nn.Linear(320, 392),
                nn.BatchNorm1d(392),
                nn.ReLU(inplace=True),
                nn.Linear(392, 10),
            )
        def forward(self, x):
            B = x.shape[0]
            # Partition 32x32x3 into 64 non-overlapping 4x4x3 patches
            patches = x.unfold(2, 4, 4).unfold(3, 4, 4)
            patches = patches.contiguous().view(B, 64, 48)
            h = self.patch_proj(patches).transpose(1, 2)
            h = torch.relu(self.patch_bn(h)).transpose(1, 2).contiguous().view(B, 2048)
            return self.mixer(h)

    class MLPHighCap(nn.Module):
        """Q1(b) High-Capacity Memorisation MLP: 3072 -> 1024 -> 512 -> 10 (3,676,682 params)"""
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(
                nn.Flatten(),
                nn.Linear(3072, 1024),
                nn.ReLU(inplace=True),
                nn.Linear(1024, 512),
                nn.ReLU(inplace=True),
                nn.Linear(512, 10),
            )
        def forward(self, x):
            return self.net(x)

    class CNNFair4Block(nn.Module):
        """Q2(a), Q3(b) & Q4 Fair Comparison CNN: 787,594 params"""
        def __init__(self):
            super().__init__()
            self.features = nn.Sequential(
                nn.Conv2d(3, 32, kernel_size=3, padding=1),
                nn.BatchNorm2d(32),
                nn.ReLU(inplace=True),
                nn.Conv2d(32, 64, kernel_size=3, padding=1),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(2, 2),
                nn.Conv2d(64, 128, kernel_size=3, padding=1),
                nn.BatchNorm2d(128),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(2, 2),
                nn.Conv2d(128, 256, kernel_size=3, padding=1),
                nn.BatchNorm2d(256),
                nn.ReLU(inplace=True),
                nn.AdaptiveAvgPool2d((2, 2)),
            )
            self.fc1 = nn.Linear(1024, 384)
            self.bn_fc = nn.BatchNorm1d(384)
            self.head = nn.Linear(384, 10)

        def forward(self, x):
            h = self.features(x).view(x.size(0), -1)
            h = torch.relu(self.bn_fc(self.fc1(h)))
            return self.head(h)

    class ConvAutoencoder(nn.Module):
        """Q3(a)-(c) Symmetric Convolutional Autoencoder with Bottleneck C_b in {2, 8, 32}"""
        def __init__(self, bottleneck_channels=8):
            super().__init__()
            self.enc_outer = nn.Sequential(
                nn.Conv2d(3, 32, kernel_size=3, stride=2, padding=1),
                nn.BatchNorm2d(32),
                nn.ReLU(inplace=True),
                nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Conv2d(64, 64, kernel_size=3, stride=2, padding=1),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
            )
            self.enc_bottleneck = nn.Conv2d(64, bottleneck_channels, kernel_size=3, stride=1, padding=1)
            self.dec_bottleneck = nn.Sequential(
                nn.Conv2d(bottleneck_channels, 64, kernel_size=3, stride=1, padding=1),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
            )
            self.dec_outer = nn.Sequential(
                nn.ConvTranspose2d(64, 64, kernel_size=4, stride=2, padding=1),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1),
                nn.BatchNorm2d(32),
                nn.ReLU(inplace=True),
                nn.ConvTranspose2d(32, 3, kernel_size=4, stride=2, padding=1),
                nn.Sigmoid(),
            )

        def encode(self, x):
            return self.enc_bottleneck(self.enc_outer(x))

        def forward(self, x):
            z = self.encode(x)
            return self.dec_outer(self.dec_bottleneck(z))
