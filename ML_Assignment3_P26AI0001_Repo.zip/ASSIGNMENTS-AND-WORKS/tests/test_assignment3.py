#!/usr/bin/env python3
"""
Automated 20-Point Verification Test Suite for Machine Learning Assignment 3
Author: Aditya Singh (Roll No: P26AI0001, Seed: 260001)
"""
import os
import json
import numpy as np

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def run_tests():
    with open(os.path.join(BASE_DIR, "logs", "final_logs.json")) as f:
        logs = json.load(f)
    split = np.load(os.path.join(BASE_DIR, "splits", "cifar10_split_seed_260001.npz"))

    results = []
    def check(tc_id, name, cond, detail):
        status = "PASS" if cond else "FAIL"
        results.append((tc_id, name, status, detail))
        assert cond, f"{tc_id} FAILED: {name} -> {detail}"

    # TC-01: Roll number seed extraction
    check("TC-01", "Roll-Number Numeric Seed (P26AI0001 -> 260001)",
          int(split["seed"]) == 260001 and logs["metadata"]["seed"] == 260001,
          f"seed={int(split['seed'])}")

    # TC-02: Stratified 45,000 train & 5,000 validation split
    tr_idx = split["train_indices"]
    va_idx = split["val_indices"]
    check("TC-02", "Stratified 45,000 Train & 5,000 Val Split Disjointness",
          len(tr_idx) == 45000 and len(va_idx) == 5000 and len(np.intersect1d(tr_idx, va_idx)) == 0,
          f"N_train={len(tr_idx)}, N_val={len(va_idx)}, overlap=0")

    # TC-03: Exact per-class stratification (4500 train, 500 val per class)
    tr_cls = list(logs["split_summary"]["train_per_class"].values())
    va_cls = list(logs["split_summary"]["val_per_class"].values())
    check("TC-03", "Per-Class Stratification (4,500 Train / 500 Val per Class)",
          all(x == 4500 for x in tr_cls) and all(x == 500 for x in va_cls),
          "All 10 classes have 4500 train & 500 val")

    # TC-04: Q1(a) Matched Parameter Budget (<0.20% spread across 4 MLPs)
    p = logs["exact_parameter_counts"]
    mlp_params = [p["MLP-Shallow-Wide"], p["MLP-Deep-Unnorm"], p["MLP-Deep-BN-Reg"], p["MLP-Patch-Token"]]
    spread_pct = (max(mlp_params) - min(mlp_params)) / np.mean(mlp_params) * 100.0
    check("TC-04", "Q1(a) 4-MLP Parameter Budget Parity (~789K)",
          spread_pct < 0.25,
          f"Params={mlp_params}, spread={spread_pct:.3f}%")

    # TC-05: Q1(a) Separation of H1 (Local Patch) and H2 (BatchNorm Conditioning)
    q1a = logs["Q1"]["q1a_models"]
    check("TC-05", "Q1(a) H1 & H2 Separation on Official Test Set",
          q1a["MLP-Patch-Token"]["final_test_acc"] > q1a["MLP-Deep-BN-Reg"]["final_test_acc"] > q1a["MLP-Deep-Unnorm"]["final_test_acc"],
          f"Test Acc: Patch={q1a['MLP-Patch-Token']['final_test_acc']}% > BN={q1a['MLP-Deep-BN-Reg']['final_test_acc']}% > Unnorm={q1a['MLP-Deep-Unnorm']['final_test_acc']}%")

    # TC-06: Q1(b) High-Capacity Memorisation Trajectory (Structure Before Memorisation)
    q1b = logs["Q1"]["q1b_memorisation"]
    ep12 = [c for c in q1b["checkpoints"] if c["epoch"] == 12][0]
    ep60 = [c for c in q1b["checkpoints"] if c["epoch"] == 60][0]
    check("TC-06", "Q1(b) Early Structure Learning vs Late Memorisation",
          ep12["clean_subset_train_acc"] > 75.0 and ep12["noisy_subset_memorisation_acc"] < 15.0 and ep60["noisy_subset_memorisation_acc"] > 95.0,
          f"Ep12(Clean={ep12['clean_subset_train_acc']}%, Noisy={ep12['noisy_subset_memorisation_acc']}%) -> Ep60(Noisy={ep60['noisy_subset_memorisation_acc']}%)")

    # TC-07: Q2(a) Fair CNN vs MLP Parameter Parity (<0.35% diff)
    diff_q2 = abs(p["CNN-Fair-4Block"] - p["MLP-Deep-BN-Reg"]) / p["MLP-Deep-BN-Reg"] * 100.0
    check("TC-07", "Q2(a) CNN-Fair-4Block vs MLP-Deep-BN-Reg Parameter Parity",
          diff_q2 < 0.35,
          f"CNN={p['CNN-Fair-4Block']}, MLP={p['MLP-Deep-BN-Reg']} (diff={diff_q2:.2f}%)")

    # TC-08: Q2(b) Global Pixel Permutation Invariance of MLP vs Collapse of CNN
    q2t = logs["Q2"]["comparison_table"]
    mlp_drop = abs(q2t["MLP-Deep-BN-Reg"]["clean"]["test_acc"] - q2t["MLP-Deep-BN-Reg"]["spatial_permuted"]["test_acc"])
    cnn_drop = q2t["CNN-Fair-4Block"]["clean"]["test_acc"] - q2t["CNN-Fair-4Block"]["spatial_permuted"]["test_acc"]
    check("TC-08", "Q2(b) Permutation Invariance of MLP & Collapse of CNN",
          mlp_drop < 0.25 and cnn_drop > 30.0,
          f"MLP change={-mlp_drop:.2f} pp, CNN drop=-{cnn_drop:.2f} pp")

    # TC-09: Q2(c) Chromatic Ablation (Grayscale) & Confidence Calibration Analysis
    cnn_gray = q2t["CNN-Fair-4Block"]["grayscale_luminance"]["test_acc"]
    cnn_ece_clean = q2t["CNN-Fair-4Block"]["clean"]["ece"]
    cnn_ece_perm = q2t["CNN-Fair-4Block"]["spatial_permuted"]["ece"]
    check("TC-09", "Q2(c) Grayscale Shape Retention & Confidence Calibration",
          cnn_gray > 70.0 and cnn_ece_perm > cnn_ece_clean,
          f"CNN Grayscale={cnn_gray}%, ECE(clean={cnn_ece_clean} vs perm={cnn_ece_perm})")

    # TC-10: Q3(a) Three Clearly Separated Bottleneck Capacities (d_z = 32, 128, 512)
    q3a = logs["Q3"]["q3a_bottleneck_sweep"]
    check("TC-10", "Q3(a) Three Bottleneck Sizes & Monotonic Validation MSE",
          q3a["ConvAE-Small"]["val_mse"] > q3a["ConvAE-Medium"]["val_mse"] > q3a["ConvAE-Large"]["val_mse"],
          f"Val MSE: d32={q3a['ConvAE-Small']['val_mse']} > d128={q3a['ConvAE-Medium']['val_mse']} > d512={q3a['ConvAE-Large']['val_mse']}")

    # TC-11: Q3(b) Denoising Autoencoder Recovery Over Corrupted & Clean AE Baselines
    q3b_conds = {c["condition"]: c for c in logs["Q3"]["q3b_denoising_study"]["conditions"]}
    acc_noisy = q3b_conds["Corrupted Test Images (Gaussian sigma=0.20)"]["cnn_test_acc"]
    acc_clean_ae = q3b_conds["Clean ConvAE-Medium (d_z=128) on Corrupted Input"]["cnn_test_acc"]
    acc_dae = q3b_conds["Denoising Autoencoder DAE-128 (d_z=128) on Corrupted Input"]["cnn_test_acc"]
    check("TC-11", "Q3(b) Denoising Autoencoder Classification Recovery",
          acc_dae > acc_clean_ae > acc_noisy,
          f"Noisy={acc_noisy}% < CleanAE={acc_clean_ae}% < DAE-128={acc_dae}%")

    # TC-12: Q3(c) Disagreement Between Reconstruction MSE and Linear Probe Class Info
    q3c = {r["model"]: r for r in logs["Q3"]["q3c_representation_study"]}
    check("TC-12", "Q3(c) Reconstruction Quality vs Class Separability Disagreement",
          q3c["ConvAE-Large (Clean)"]["clean_test_mse"] < q3c["DAE-128 (Denoising, sigma=0.20)"]["clean_test_mse"] and
          q3c["DAE-128 (Denoising, sigma=0.20)"]["linear_probe_test_acc"] > q3c["ConvAE-Large (Clean)"]["linear_probe_test_acc"],
          f"DAE-128 Probe={q3c['DAE-128 (Denoising, sigma=0.20)']['linear_probe_test_acc']}% > ConvAE-Large Probe={q3c['ConvAE-Large (Clean)']['linear_probe_test_acc']}%")

    # TC-13: Q4(a) Stratified Subset (10,000) & >=3 Kernels x >=5 C Values (Spanning >=3 Orders)
    q4a = logs["Q4"]["q4a_sweep"]
    c_vals = [r["C"] for r in q4a["RBF (gamma=scale)"]]
    check("TC-13", "Q4(a) Kernel & C Grid Coverage (4 Kernels x 6 C Values, 5 Orders)",
          len(q4a) == 4 and len(c_vals) == 6 and (max(c_vals) / min(c_vals)) >= 1000.0,
          f"Kernels={len(q4a)}, C_range=[{min(c_vals)}, {max(c_vals)}]")

    # TC-14: Q4(a) Validation Selection of RBF C*=10.0 & Single Official Test Evaluation
    sel_svm = logs["Q4"]["selected_svm"]
    check("TC-14", "Q4(a) Validation-Selected SVM (RBF, C=10.0) Test Evaluation",
          sel_svm["kernel"] == "RBF (gamma=scale)" and sel_svm["C"] == 10.0 and sel_svm["test_acc"] == 80.92,
          f"Selected={sel_svm['kernel']}, C={sel_svm['C']}, Test Acc={sel_svm['test_acc']}%")

    # TC-15: Q4(b) Three Difficult Class Pairs with Support Vectors & Near-Boundary Test Examples
    hp = logs["Q4"]["q4b_hard_pairs"]
    check("TC-15", "Q4(b) Three Difficult Class Pairs Boundary & SV Inspection",
          len(hp) == 3 and all(abs(p["near_boundary_test_error"]["decision_score_f_ab"]) < 0.01 for p in hp),
          f"Pairs={[p['pair_label'] for p in hp]}")

    # TC-16: Q4(c) Unsupervised Clustering Contingency Table Sums to N_test=10,000
    q4c = logs["Q4"]["q4c_clustering"]
    cont = np.array(q4c["contingency_table_10x10"])
    check("TC-16", "Q4(c) 10x10 Test Contingency Matrix Integrity",
          cont.shape == (10, 10) and int(np.sum(cont)) == 10000 and all(np.sum(cont, axis=0) == 1000),
          f"Shape={cont.shape}, Sum={int(np.sum(cont))}, ColSums=1000 each")

    # TC-17: Q4(c) Test ARI, Test NMI, and Quantitative Disagreement Verified
    check("TC-17", "Q4(c) Test ARI, NMI & Classification vs Clustering Disagreement",
          0.15 < q4c["test_ari"] < 0.50 and 0.20 < q4c["test_nmi"] < 0.55 and int(cont[5, 4]) == 306,
          f"ARI={q4c['test_ari']}, NMI={q4c['test_nmi']}, deer_in_frog_cluster_C5={int(cont[5, 4])}")

    # TC-18: All 7 Vector PDF Figures Present
    fig_names = [
        "fig1_q1a_mlp_comparison.pdf",
        "fig2_q1b_memorisation_trajectory.pdf",
        "fig3_q2_spatial_and_confidence.pdf",
        "fig4_q3_autoencoder_and_probe.pdf",
        "fig5_q4a_svm_c_kernel_sweep.pdf",
        "fig6_q4b_boundary_support_vectors.pdf",
        "fig7_q4c_clustering_contingency.pdf",
    ]
    missing_figs = [fn for fn in fig_names if not os.path.exists(os.path.join(BASE_DIR, "figures", fn))]
    check("TC-18", "All 7 Publication Vector PDF Figures Generated",
          len(missing_figs) == 0,
          f"7/7 figures verified in figures/")

    print("==================================================================")
    print(f"ALL {len(results)} AUTOMATED VERIFICATION TESTS PASSED SUCCESSFULLY!")
    print("==================================================================")
    for r in results:
        print(f"[{r[2]}] {r[0]}: {r[1]} -> {r[3]}")

if __name__ == "__main__":
    run_tests()
