#!/usr/bin/env bash
set -euo pipefail

echo "=================================================================="
echo "Machine Learning Assignment 3 — Full Reproduction Pipeline"
echo "Author: Aditya Singh | Roll No: P26AI0001 | Seed: 260001"
echo "=================================================================="

python3 scripts/run_all.py
python3 tests/test_assignment3.py

if command -v pdflatex >/dev/null 2>&1; then
    echo "Compiling CVPR two-column report PDF..."
    (cd report && pdflatex -interaction=nonstopmode -halt-on-error cvpr_report_p26ai0001.tex >/dev/null && pdflatex -interaction=nonstopmode -halt-on-error cvpr_report_p26ai0001.tex >/dev/null)
    echo "Report compiled at report/cvpr_report_p26ai0001.pdf"
fi

echo "All experiments, figures, logs, and verification tests completed!"
