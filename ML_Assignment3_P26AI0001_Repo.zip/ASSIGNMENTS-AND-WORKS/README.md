# Machine Learning: Assignment 3 — MLPs, CNNs, Autoencoders, SVMs and Clustering on CIFAR-10

- **Author:** Aditya Singh
- **Roll Number:** `P26AI0001` (Numeric RNG Seed: `260001`)
- **Email:** `p26ai0001@iitj.ac.in`
- **Institution:** School of Artificial Intelligence and Data Science, Indian Institute of Technology Jodhpur (IIT Jodhpur)
- **Repository:** [https://github.com/Adityasingh016/ASSIGNMENTS-AND-WORKS](https://github.com/Adityasingh016/ASSIGNMENTS-AND-WORKS)

## Repository Structure

```text
ASSIGNMENTS-AND-WORKS/
├── configs/
│   └── config.yaml                       # All hyperparameters, architectures & seed settings
├── splits/
│   ├── cifar10_split_seed_260001.npz     # Saved 45,000 train / 5,000 val stratified indices + Q4 subset + spatial perm
│   └── cifar10_split_seed_260001.json    # Human-readable split metadata & per-class counts
├── src/
│   └── pytorch_cifar10_models.py         # PyTorch model definitions for Q1, Q2, and Q3
├── scripts/
│   └── run_all.py                        # End-to-end deterministic experiment & figure runner
├── logs/
│   └── final_logs.json                   # Complete experimental metrics for every table & plot
├── figures/
│   ├── fig1_q1a_mlp_comparison.pdf       # Q1(a) 4-MLP training/validation accuracy & loss curves
│   ├── fig2_q1b_memorisation_trajectory.pdf # Q1(b) 60-epoch clean structure vs label noise memorisation
│   ├── fig3_q2_spatial_and_confidence.pdf   # Q2(a)-(c) Clean, Permuted, Grayscale & reliability calibration
│   ├── fig4_q3_autoencoder_and_probe.pdf    # Q3(a)-(c) Reconstructions, denoising & linear probe comparison
│   ├── fig5_q4a_svm_c_kernel_sweep.pdf      # Q4(a) C and kernel sweep validation accuracy & SV fraction
│   ├── fig6_q4b_boundary_support_vectors.pdf# Q4(b) Support vectors & near-boundary test examples (3 pairs)
│   └── fig7_q4c_clustering_contingency.pdf  # Q4(c) 10x10 test contingency matrix & SVM vs clustering recall
├── report/
│   ├── cvpr_report_p26ai0001.tex         # Self-contained CVPR two-column LaTeX source
│   └── ML_Assignment3_CVPR_Report_P26AI0001.pdf
├── tests/
│   └── test_assignment3.py               # 20-point automated verification test suite
├── environment.yml                       # Conda environment specification
├── requirements.txt                      # Python pip dependencies
└── reproduce.sh                          # Single-command end-to-end reproduction script
```

## Exact Reproduction Commands

```bash
# 1. Create environment (Conda or pip)
conda env create -f environment.yml && conda activate ml-assignment3-p26ai0001
# OR: pip install -r requirements.txt

# 2. Run the entire experimental suite, regenerate all splits, logs, figures, tests, and PDF report:
bash reproduce.sh
```
